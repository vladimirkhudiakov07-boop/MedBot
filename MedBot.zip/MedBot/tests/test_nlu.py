from __future__ import annotations

import pytest

from app import nlu


@pytest.mark.parametrize(
    ("text", "category"),
    [
        ("болит голова третий день", "pain"),
        ("температура 38 и озноб", "fever"),
        ("не могу дышать, кашель", "breathing"),
        ("тошнит и понос", "gi"),
        ("сыпь и зуд на руках", "skin"),
        ("онемела рука", "neuro"),
        ("упал с лестницы, ушиб", "trauma"),
        ("болит горло", "ent"),
    ],
)
def test_detect_category(text: str, category: str) -> None:
    assert nlu.detect_category(text) == category


def test_negation_cancels_token() -> None:
    assert nlu.detect_tokens("нет температуры") == set()
    assert nlu.detect_category("температуры нет") is None


def test_detect_tokens_handles_inflection() -> None:
    assert "fever" in nlu.detect_tokens("температура 38,5")
    assert "headache" in nlu.detect_tokens("головная боль")


@pytest.mark.parametrize(
    ("text", "flag"),
    [
        ("сильно болит грудь", "chest_pain"),
        ("не хватает воздуха", "dyspnea_rest"),
        ("была потеря сознания", "syncope"),
        ("начались судороги", "seizure"),
        ("кровь не останавливается", "bleeding"),
        ("перекосило лицо и не могу говорить", "stroke"),
        ("отекли губы и горло", "anaphylaxis"),
        ("острая боль в животе", "severe_abdomen"),
        ("травма головы, ударился головой", "head_injury"),
    ],
)
def test_detect_red_flags(text: str, flag: str) -> None:
    assert flag in nlu.detect_red_flags(text)


def test_negated_red_flag_is_ignored() -> None:
    assert "chest_pain" not in nlu.detect_red_flags("болей в груди нет")
    assert "chest_pain" not in nlu.detect_red_flags("боль в груди отсутствует")
    assert "dyspnea_rest" not in nlu.detect_red_flags("одышки в покое нет")
    assert "syncope" not in nlu.detect_red_flags("потери сознания не было")


def test_negation_with_continuation_keeps_red_flag() -> None:
    assert "chest_pain" in nlu.detect_red_flags("не проходит боль в груди")
    assert "chest_pain" in nlu.detect_red_flags("боль в груди не проходит")


def test_temperature_and_duration_parsers() -> None:
    assert nlu.parse_temperature("38,5") == "mid"
    assert nlu.parse_temperature("39.5") == "high"
    assert nlu.parse_temperature("39.8") == "critical"
    assert nlu.match_duration("10 дней") == ">week"


def test_child_context_is_not_age() -> None:
    assert nlu.parse_age("у ребенка температура 39.5") is None


def test_parse_age() -> None:
    assert nlu.parse_age("34") == 34
    assert nlu.parse_age("мне 45 лет") == 45
    assert nlu.parse_age("двадцать") == 20
    assert nlu.parse_age("не скажу") is None


def test_parse_duration() -> None:
    assert nlu.parse_duration("2 дня") == "1-3d"
    assert nlu.parse_duration("уже неделю") == ">week"
    assert nlu.parse_duration("пару часов") == "hours"


def test_parse_severity() -> None:
    assert nlu.parse_severity("7") == 7
    assert nlu.parse_severity("невыносимо") == 9
    assert nlu.parse_severity("слабо") == 2


def test_parse_yes_no() -> None:
    assert nlu.parse_yes_no("да") == "yes"
    assert nlu.parse_yes_no("нет") == "no"
    assert nlu.parse_yes_no("не знаю") == "unknown"


def test_parse_meds_detects_anticoagulant() -> None:
    assert nlu.parse_meds("пью варфарин") == "anticoagulant"
    assert nlu.parse_meds("нет") == "none"


def test_parse_payment() -> None:
    assert nlu.parse_payment("ДМС") == "dms"
    assert nlu.parse_payment("платно") == "paid"


def test_detect_items_chronic() -> None:
    assert "diabetes" in nlu.match_chronic("диабет и гипертония")
    assert nlu.match_chronic("нет") == ["none"]
    assert nlu.match_chronic("нет диабета") == ["none"]


def test_allergy_negation() -> None:
    assert nlu.parse_allergy("нет аллергии") == "none"
    assert nlu.parse_allergy("аллергия на пенициллин") in {"drug", "unknown"}


def test_pregnancy_negation() -> None:
    assert nlu.parse_pregnancy("не беременна") == "no"
    assert nlu.parse_pregnancy("беременна") == "pregnant"


def test_parse_detail() -> None:
    assert nlu.parse_detail("pain", "болит грудь") == "chest"
    assert nlu.parse_detail("skin", "чешется") == "itch"
