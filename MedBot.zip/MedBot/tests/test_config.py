from __future__ import annotations

import pytest

from app.config import load_settings

ENV_KEYS = (
    "MAX_BOT_TOKEN",
    "MAX_BOT_TOKEN_FILE",
    "BOT_MODE",
    "MAX_API_BASE",
    "MAX_API_HOSTS",
    "WEBHOOK_HOST",
    "WEBHOOK_PORT",
    "WEBHOOK_PATH",
    "WEBHOOK_URL",
    "WEBHOOK_SECRET",
    "WEBHOOK_SECRET_FILE",
    "SESSION_TTL",
    "SESSION_MAX_AGE",
    "HISTORY_LIMIT",
    "MAX_SESSIONS",
    "MAX_TEXT_LENGTH",
    "MAX_INFLIGHT_UPDATES",
    "MAX_UPDATES_PER_REQUEST",
    "WEBHOOK_MAX_BODY",
    "USER_MESSAGES_PER_MINUTE",
    "USER_MESSAGE_BURST",
    "MAX_INSECURE_SSL",
    "MAX_CA_BUNDLE",
    "DB_PATH",
    "DB_SALT",
    "ADMIN_IDS",
)


def load(tmp_path, monkeypatch, **overrides):
    for key in ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    values = {"MAX_BOT_TOKEN": "test-token", **overrides}
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    return load_settings(tmp_path / "missing.env")


def test_secure_defaults(tmp_path, monkeypatch) -> None:
    settings = load(tmp_path, monkeypatch)
    assert settings.mode == "polling"
    assert settings.webhook_host == "127.0.0.1"
    assert settings.api_base == "https://platform-api2.max.ru"
    assert settings.max_sessions == 10000
    assert settings.session_max_age == 21600
    assert settings.max_text_length == 4000
    assert settings.max_inflight_updates == 50
    assert settings.max_updates_per_request == 100
    assert settings.webhook_max_body == 262144
    assert settings.user_messages_per_minute == 60
    assert settings.user_message_burst == 20
    assert settings.db_path.endswith("data\\medbot.sqlite3") or settings.db_path.endswith("data/medbot.sqlite3")
    assert settings.admin_ids == frozenset()


def test_admin_ids_are_parsed(tmp_path, monkeypatch) -> None:
    settings = load(tmp_path, monkeypatch, ADMIN_IDS="1, 2;3, bad")
    assert settings.admin_ids == frozenset({1, 2, 3})


def test_webhook_requires_url(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(
            tmp_path,
            monkeypatch,
            BOT_MODE="webhook",
            WEBHOOK_SECRET="a" * 32,
        )


def test_webhook_requires_strong_secret(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(
            tmp_path,
            monkeypatch,
            BOT_MODE="webhook",
            WEBHOOK_SECRET="short",
            WEBHOOK_URL="https://bot.example.ru/webhook",
        )


def test_api_base_must_use_allowed_host(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(tmp_path, monkeypatch, MAX_API_BASE="https://evil.example")


def test_api_base_must_use_https(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(tmp_path, monkeypatch, MAX_API_BASE="http://platform-api2.max.ru")


def test_webhook_url_must_be_https_and_have_path(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(
            tmp_path,
            monkeypatch,
            BOT_MODE="webhook",
            WEBHOOK_SECRET="a" * 32,
            WEBHOOK_URL="http://bot.example.ru/webhook",
        )
    with pytest.raises(SystemExit):
        load(
            tmp_path,
            monkeypatch,
            BOT_MODE="webhook",
            WEBHOOK_SECRET="a" * 32,
            WEBHOOK_URL="https://bot.example.ru",
        )


def test_webhook_url_path_must_match_webhook_path(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(
            tmp_path,
            monkeypatch,
            BOT_MODE="webhook",
            WEBHOOK_SECRET="a" * 32,
            WEBHOOK_URL="https://bot.example.ru/other",
        )


def test_webhook_refuses_insecure_tls(tmp_path, monkeypatch) -> None:
    with pytest.raises(SystemExit):
        load(
            tmp_path,
            monkeypatch,
            BOT_MODE="webhook",
            WEBHOOK_SECRET="a" * 32,
            WEBHOOK_URL="https://bot.example.ru/webhook",
            MAX_INSECURE_SSL="1",
        )


def test_token_can_come_from_file(tmp_path, monkeypatch) -> None:
    token_file = tmp_path / "token.txt"
    token_file.write_text("file-token\n", encoding="utf-8")
    for key in ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("MAX_BOT_TOKEN_FILE", str(token_file))
    settings = load_settings(tmp_path / "missing.env")
    assert settings.token == "file-token"


def test_secret_can_come_from_file(tmp_path, monkeypatch) -> None:
    secret_file = tmp_path / "secret.txt"
    secret_file.write_text("b" * 32, encoding="utf-8")
    for key in ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("MAX_BOT_TOKEN", "test-token")
    monkeypatch.setenv("BOT_MODE", "webhook")
    monkeypatch.setenv("WEBHOOK_URL", "https://bot.example.ru/webhook")
    monkeypatch.setenv("WEBHOOK_SECRET_FILE", str(secret_file))
    settings = load_settings(tmp_path / "missing.env")
    assert settings.webhook_secret == "b" * 32
