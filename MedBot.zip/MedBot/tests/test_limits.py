from __future__ import annotations

from app.limits import Deduplicator, TokenBucket


def test_deduplicator_ignores_duplicate_until_ttl(monkeypatch) -> None:
    now = [100.0]
    monkeypatch.setattr("app.limits.time.monotonic", lambda: now[0])
    dedupe = Deduplicator(max_entries=10, ttl_seconds=60)
    assert dedupe.remember("m1") is True
    assert dedupe.remember("m1") is False
    now[0] += 61
    assert dedupe.remember("m1") is True


def test_deduplicator_evicts_oldest_entry() -> None:
    dedupe = Deduplicator(max_entries=2, ttl_seconds=3600)
    assert dedupe.remember("a") is True
    assert dedupe.remember("b") is True
    assert dedupe.remember("c") is True
    assert dedupe.remember("a") is True


def test_token_bucket_limits_burst(monkeypatch) -> None:
    now = [100.0]
    monkeypatch.setattr("app.limits.time.monotonic", lambda: now[0])
    bucket = TokenBucket(per_minute=60, burst=1)
    assert bucket.allow("u1") is True
    assert bucket.allow("u1") is False
    now[0] += 1.0
    assert bucket.allow("u1") is True
    assert bucket.allow("u2") is True
