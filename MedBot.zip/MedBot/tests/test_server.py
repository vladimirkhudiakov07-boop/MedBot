from __future__ import annotations

import asyncio

import pytest
from aiohttp.test_utils import TestClient, TestServer

from app.config import Settings
from app.server import build_webhook_app


class FakeDispatcher:
    def __init__(self) -> None:
        self.updates: list[dict] = []

    async def handle_update(self, update: dict) -> None:
        self.updates.append(update)


class BlockingDispatcher:
    def __init__(self) -> None:
        self.release = asyncio.Event()

    async def handle_update(self, _update: dict) -> None:
        await self.release.wait()


def make_settings(**overrides) -> Settings:
    values = {
        "token": "test-token",
        "api_base": "https://platform-api2.max.ru",
        "mode": "webhook",
        "poll_timeout": 1,
        "poll_limit": 10,
        "webhook_host": "127.0.0.1",
        "webhook_port": 8080,
        "webhook_path": "/webhook",
        "webhook_url": "https://bot.example.ru/webhook",
        "webhook_secret": "a" * 32,
        "session_ttl": 600,
        "history_limit": 5,
        "messages_per_second": 2.0,
        "log_level": "INFO",
    }
    values.update(overrides)
    return Settings(**values)


def secret_headers() -> dict[str, str]:
    return {"X-Max-Bot-Api-Secret": "a" * 32}


async def make_client(settings: Settings, dispatcher: FakeDispatcher) -> TestClient:
    client = TestClient(TestServer(build_webhook_app(dispatcher, settings)))
    await client.start_server()
    return client


def test_webhook_refuses_to_start_without_secret() -> None:
    with pytest.raises(RuntimeError):
        build_webhook_app(FakeDispatcher(), make_settings(webhook_secret=""))


async def test_webhook_rejects_wrong_secret() -> None:
    dispatcher = FakeDispatcher()
    client = await make_client(make_settings(), dispatcher)
    try:
        response = await client.post(
            "/webhook",
            json={"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}},
            headers={"X-Max-Bot-Api-Secret": "b" * 32},
        )
        assert response.status == 403
        assert dispatcher.updates == []
    finally:
        await client.close()


async def test_webhook_accepts_valid_request() -> None:
    dispatcher = FakeDispatcher()
    client = await make_client(make_settings(), dispatcher)
    try:
        response = await client.post(
            "/webhook",
            json={"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}},
            headers=secret_headers(),
        )
        assert response.status == 200
        await asyncio.sleep(0.05)
        assert dispatcher.updates
    finally:
        await client.close()


async def test_webhook_requires_json_content_type() -> None:
    dispatcher = FakeDispatcher()
    client = await make_client(make_settings(), dispatcher)
    try:
        response = await client.post(
            "/webhook",
            data="{}",
            headers={**secret_headers(), "Content-Type": "text/plain"},
        )
        assert response.status == 415
    finally:
        await client.close()


async def test_webhook_rejects_invalid_json() -> None:
    dispatcher = FakeDispatcher()
    client = await make_client(make_settings(), dispatcher)
    try:
        response = await client.post(
            "/webhook",
            data="{",
            headers={**secret_headers(), "Content-Type": "application/json"},
        )
        assert response.status == 400
    finally:
        await client.close()


async def test_webhook_rejects_too_many_updates() -> None:
    dispatcher = FakeDispatcher()
    client = await make_client(make_settings(max_updates_per_request=1), dispatcher)
    try:
        response = await client.post(
            "/webhook",
            json={
                "updates": [
                    {"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}},
                    {"update_type": "bot_started", "chat_id": 11, "user": {"user_id": 2}},
                ]
            },
            headers=secret_headers(),
        )
        assert response.status == 413
        assert dispatcher.updates == []
    finally:
        await client.close()


async def test_webhook_returns_busy_when_inflight_limit_is_reached() -> None:
    dispatcher = BlockingDispatcher()
    client = await make_client(make_settings(max_inflight_updates=1), dispatcher)
    try:
        first = await client.post(
            "/webhook",
            json={"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}},
            headers=secret_headers(),
        )
        assert first.status == 200
        second = await client.post(
            "/webhook",
            json={"update_type": "bot_started", "chat_id": 11, "user": {"user_id": 2}},
            headers=secret_headers(),
        )
        assert second.status == 503
        assert second.headers["Retry-After"] == "1"
        dispatcher.release.set()
    finally:
        await client.close()


async def test_health_is_minimal() -> None:
    dispatcher = FakeDispatcher()
    client = await make_client(make_settings(), dispatcher)
    try:
        response = await client.get("/health")
        assert response.status == 200
        assert await response.json() == {"ok": True}
    finally:
        await client.close()
