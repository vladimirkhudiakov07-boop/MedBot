from __future__ import annotations

import time
from dataclasses import replace

import pytest
from aiohttp import web
from aiohttp.test_utils import TestServer

from app.config import Settings
from app.keyboards import KeyboardError, decode_payload, encode_payload, inline_keyboard
from app.max_api import MaxApiError, MaxClient, RateLimiter, _fit_text, _ssl_context
from app.models import ReplyTarget


def make_settings(api_base: str) -> Settings:
    return Settings(
        token="test-token",
        api_base=api_base,
        mode="polling",
        poll_timeout=1,
        poll_limit=10,
        webhook_host="127.0.0.1",
        webhook_port=8080,
        webhook_path="/webhook",
        webhook_url="",
        webhook_secret="",
        session_ttl=600,
        history_limit=5,
        messages_per_second=2.0,
        log_level="INFO",
    )


def test_payload_roundtrip() -> None:
    payload = {"k": "pick", "f": "detail", "v": "chest"}
    assert decode_payload(encode_payload(payload)) == payload


def test_payload_fallback_for_plain_text() -> None:
    assert decode_payload("просто текст").get("k") == "text"


def test_keyboard_rejects_empty() -> None:
    with pytest.raises(KeyboardError):
        inline_keyboard([])


def test_keyboard_rejects_wide_row() -> None:
    row = [{"type": "callback", "text": "x", "payload": "{}"} for _ in range(8)]
    with pytest.raises(KeyboardError):
        inline_keyboard([row])


def test_keyboard_rejects_many_special_buttons() -> None:
    row = [{"type": "link", "text": "x", "url": "https://example.com"} for _ in range(4)]
    with pytest.raises(KeyboardError):
        inline_keyboard([row])


def test_fit_text_closes_markdown() -> None:
    text = "**Заголовок** " + "слово " * 900
    fitted = _fit_text(text)
    assert len(fitted) <= 4000
    assert fitted.count("**") % 2 == 0


def test_ssl_context_insecure_mode() -> None:
    settings = replace(make_settings("https://example.com"), insecure_ssl=True)
    assert _ssl_context(settings) is False


def test_ssl_context_missing_bundle_exits() -> None:
    settings = replace(make_settings("https://example.com"), ca_bundle="C:/no-such-dir/ca.pem")
    with pytest.raises(SystemExit):
        _ssl_context(settings)


def test_reply_target_prefers_user_id() -> None:
    target = ReplyTarget(chat_id=10, user_id=1)
    assert target.params() == {"user_id": 1}


def test_reply_target_uses_chat_id_for_group() -> None:
    target = ReplyTarget(chat_id=10, user_id=None)
    assert target.params() == {"chat_id": 10}


async def test_rate_limiter_spaces_calls() -> None:
    limiter = RateLimiter(per_second=10)
    started = time.monotonic()
    for _ in range(3):
        await limiter.wait("same")
    assert time.monotonic() - started >= 0.18


async def test_send_message_request_shape() -> None:
    captured: dict[str, object] = {}

    async def handle(request: web.Request) -> web.Response:
        captured["authorization"] = request.headers.get("Authorization")
        captured["query"] = dict(request.query)
        captured["payload"] = await request.json()
        return web.json_response({"message": {"body": {"mid": "m1"}}})

    app = web.Application()
    app.router.add_post("/messages", handle)
    server = TestServer(app)
    await server.start_server()
    client = MaxClient(make_settings(str(server.make_url("")).rstrip("/")))
    await client.open()
    try:
        await client.send_message({"user_id": 7}, "привет", inline_keyboard([[{"type": "callback", "text": "ok", "payload": "{}"}]]))
    finally:
        await client.close()
        await server.close()

    assert captured["authorization"] == "test-token"
    assert captured["query"] == {"user_id": "7"}
    payload = captured["payload"]
    assert payload["text"] == "привет"
    assert payload["attachments"][0]["type"] == "inline_keyboard"


async def test_get_updates_passes_marker() -> None:
    captured: dict[str, object] = {}

    async def handle(request: web.Request) -> web.Response:
        captured["query"] = dict(request.query)
        return web.json_response({"updates": [], "marker": 42})

    app = web.Application()
    app.router.add_get("/updates", handle)
    server = TestServer(app)
    await server.start_server()
    client = MaxClient(make_settings(str(server.make_url("")).rstrip("/")))
    await client.open()
    try:
        page = await client.get_updates(marker=41, timeout=1, limit=10)
    finally:
        await client.close()
        await server.close()

    assert page["marker"] == 42
    params = captured["query"]
    assert params["marker"] == "41"
    assert params["timeout"] == "1"
    assert params["limit"] == "10"


async def test_api_error_is_raised() -> None:
    async def handle(_: web.Request) -> web.Response:
        return web.json_response({"code": "not.found", "message": "Resource not found"}, status=404)

    app = web.Application()
    app.router.add_get("/me", handle)
    server = TestServer(app)
    await server.start_server()
    client = MaxClient(make_settings(str(server.make_url("")).rstrip("/")))
    await client.open()
    try:
        with pytest.raises(Exception) as error:
            await client.get_me()
    finally:
        await client.close()
        await server.close()
    assert "404" in str(error.value)


async def test_redirects_are_not_followed() -> None:
    target_hits = 0

    async def redirect(_: web.Request) -> web.Response:
        raise web.HTTPFound("/target")

    async def target(_: web.Request) -> web.Response:
        nonlocal target_hits
        target_hits += 1
        return web.json_response({"id": 1})

    app = web.Application()
    app.router.add_get("/me", redirect)
    app.router.add_get("/target", target)
    server = TestServer(app)
    await server.start_server()
    client = MaxClient(make_settings(str(server.make_url("")).rstrip("/")))
    await client.open()
    try:
        with pytest.raises(MaxApiError):
            await client.get_me()
    finally:
        await client.close()
        await server.close()
    assert target_hits == 0

