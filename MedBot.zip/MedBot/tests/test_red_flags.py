from __future__ import annotations

from app.models import Answers
from app.red_flags import UNIVERSAL_QUESTIONS, age_specific_questions


def keys(questions) -> set[str]:
    return {question.key for question in questions}


def test_universal_block_covers_minimal_red_flags() -> None:
    found = keys(UNIVERSAL_QUESTIONS)
    assert {
        "chest_pain",
        "dyspnea_rest",
        "syncope",
        "seizure",
        "bleeding",
        "stroke",
        "anaphylaxis",
        "severe_abdomen",
        "head_injury",
    } <= found


def test_universal_block_is_first_and_fixed() -> None:
    assert len(UNIVERSAL_QUESTIONS) == 9
    assert UNIVERSAL_QUESTIONS[0].key == "chest_pain"
    assert UNIVERSAL_QUESTIONS[-1].key == "head_injury"


def test_child_fever_is_checked_for_children() -> None:
    assert "child_fever" in keys(age_specific_questions(Answers(age=5, category="fever")))


def test_pregnancy_bleeding_is_checked_for_women_of_childbearing_age() -> None:
    assert "pregnancy_bleeding" in keys(age_specific_questions(Answers(age=30, sex="female")))


def test_no_age_specific_questions_for_adult_man() -> None:
    assert age_specific_questions(Answers(age=40, sex="male")) == []
