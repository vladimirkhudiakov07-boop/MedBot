from __future__ import annotations

from app.instance_lock import InstanceLock


def test_second_instance_is_blocked(tmp_path) -> None:
    first = InstanceLock(tmp_path / "bot.lock")
    second = InstanceLock(tmp_path / "bot.lock")
    assert first.acquire() is True
    try:
        assert second.acquire() is False
    finally:
        first.release()
    assert second.acquire() is True
    second.release()
