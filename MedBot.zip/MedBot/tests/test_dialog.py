from __future__ import annotations

from app.dialog import CallbackOutcome, Dialog
from app.models import Outgoing
from app.sessions import Session
from app.triage import Place, Urgency

DIALOG = Dialog()
UNIVERSAL_COUNT = 9


def make_session() -> Session:
    return Session(key="u1", chat_id=10, user_id=1)


def pick(session: Session, field: str, value: str) -> tuple[Outgoing, ...]:
    return DIALOG.handle_callback(session, {"k": "pick", "f": field, "v": value}).messages


def nav(session: Session, action: str) -> CallbackOutcome:
    return DIALOG.handle_callback(session, {"k": "nav", "v": action})


def start(session: Session) -> tuple[Outgoing, ...]:
    DIALOG.welcome(session)
    return nav(session, "begin").messages


def answer_flags(session: Session, value: str = "no") -> None:
    while session.state in {"red_flags", "vital_flags"}:
        DIALOG.handle_callback(session, {"k": "rf", "v": value})


def drive_to_complaint(session: Session, age: str = "adult", sex: str = "male") -> None:
    start(session)
    answer_flags(session)
    pick(session, "age", age)
    pick(session, "sex", sex)
    answer_flags(session)


def complete_from_complaint(session: Session) -> tuple[Outgoing, ...]:
    pick(session, "complaint", "pain")
    pick(session, "detail", "chest")
    pick(session, "duration", "hours")
    pick(session, "severity", "5")
    assert session.state == "chronic"
    DIALOG.handle_callback(session, {"k": "done", "f": "chronic", "v": ""})
    pick(session, "meds", "none")
    pick(session, "allergies", "none")
    pick(session, "surgery", "no")
    DIALOG.handle_callback(session, {"k": "done", "f": "heredity", "v": ""})
    if session.state == "pregnancy":
        pick(session, "pregnancy", "no")
    pick(session, "habits", "skip")
    return pick(session, "payment", "oms")


def test_welcome_starts_dialog() -> None:
    session = make_session()
    messages = DIALOG.welcome(session)
    assert session.state == "start"
    assert "не ставлю диагноз" in messages[0].text.lower()
    assert "103" in messages[0].text
    assert messages[0].keyboard is not None


def test_critical_questions_come_before_demographics() -> None:
    session = make_session()
    begin = start(session)
    assert session.state == "red_flags"
    assert "Признак 1 из 9" in begin[0].text
    assert "боль" in begin[0].text.lower() and "груди" in begin[0].text.lower()

    answer_flags(session)
    assert session.state == "age"
    age_question = DIALOG.current(session)[0]
    assert "Сколько вам лет" in age_question.text


def test_menu_button_opens_menu_and_resumes() -> None:
    session = make_session()
    start(session)
    menu = nav(session, "menu")
    assert "Меню" in menu.messages[0].text
    assert menu.messages[0].keyboard is not None
    assert session.state == "red_flags"

    resume = nav(session, "resume")
    assert session.state == "red_flags"
    assert "Признак 1 из 9" in resume.messages[0].text


def test_question_keyboard_has_menu_button() -> None:
    session = make_session()
    start(session)
    keyboard = DIALOG.current(session)[0].keyboard
    labels = [button["text"] for row in keyboard["payload"]["buttons"] for button in row]
    assert any("Меню" in label for label in labels)


def test_surgery_answer_shows_russian_label() -> None:
    session = make_session()
    drive_to_complaint(session)
    pick(session, "complaint", "pain")
    pick(session, "detail", "chest")
    pick(session, "duration", "hours")
    pick(session, "severity", "5")
    DIALOG.handle_callback(session, {"k": "done", "f": "chronic", "v": ""})
    pick(session, "meds", "none")
    pick(session, "allergies", "none")
    assert session.state == "surgery"
    outcome = DIALOG.handle_callback(session, {"k": "pick", "f": "surgery", "v": "no"})
    assert outcome.ack_text == "✅ Нет"


def test_full_happy_path() -> None:
    session = make_session()
    drive_to_complaint(session)
    assert session.state == "complaint"
    assert "Шаг 4 из 14" in DIALOG.current(session)[0].text

    final = complete_from_complaint(session)
    assert session.state == "result"
    assert session.completed is True
    assert session.persisted is False
    assert session.result is not None
    assert session.result.urgency is Urgency.URGENT_24H
    assert session.result.specialty == "кардиолог"
    assert session.result.place is Place.EMERGENCY_ROOM
    assert "Итог опроса" in final[0].text
    assert "103" in final[0].text and "112" in final[0].text


def test_back_inside_critical_block() -> None:
    session = make_session()
    start(session)
    DIALOG.handle_callback(session, {"k": "rf", "v": "no"})
    assert session.rf_index == 1
    back = nav(session, "back")
    assert session.state == "red_flags"
    assert "Признак 1 из 9" in back.messages[0].text
    back_again = nav(session, "back")
    assert session.state == "start"
    assert "МедБот" in back_again.messages[0].text


def test_back_from_age_returns_to_screening() -> None:
    session = make_session()
    start(session)
    answer_flags(session)
    assert session.state == "age"
    back = nav(session, "back")
    assert session.state == "red_flags"
    assert "Признак 9 из 9" in back.messages[0].text


def test_female_adult_gets_pregnancy_screening() -> None:
    session = make_session()
    start(session)
    answer_flags(session)
    pick(session, "age", "adult")
    messages = pick(session, "sex", "female")
    assert session.state == "vital_flags"
    assert "Признак 1 из 1" in messages[0].text
    assert "беремен" in messages[0].text.lower()
    answer_flags(session)
    assert session.state == "complaint"


def test_child_gets_fever_screening() -> None:
    session = make_session()
    start(session)
    answer_flags(session)
    pick(session, "age", "child")
    messages = pick(session, "sex", "male")
    assert session.state == "vital_flags"
    assert "39,5" in messages[0].text
    answer_flags(session)
    assert session.state == "complaint"


def test_red_flag_interrupts_before_demographics() -> None:
    session = make_session()
    start(session)
    outcome = DIALOG.handle_callback(session, {"k": "rf", "v": "yes"})
    assert session.state == "emergency"
    assert session.completed is True
    assert "103" in outcome.messages[0].text
    assert session.result is not None and session.result.place is Place.AMBULANCE

    after = DIALOG.handle_callback(session, {"k": "pick", "f": "age", "v": "adult"})
    assert after.messages == ()


def test_free_text_red_flag_at_start() -> None:
    session = make_session()
    DIALOG.welcome(session)
    messages = DIALOG.handle_text(session, "онемела рука и перекосило лицо")
    assert session.state == "emergency"
    assert "103" in messages[0].text


def test_begin_text_goes_to_critical_block() -> None:
    session = make_session()
    DIALOG.welcome(session)
    messages = DIALOG.handle_text(session, "начать")
    assert session.state == "red_flags"
    assert "Признак 1 из 9" in messages[0].text


def test_multiselect_toggle_and_done() -> None:
    session = make_session()
    drive_to_complaint(session)
    pick(session, "complaint", "pain")
    pick(session, "detail", "chest")
    pick(session, "duration", "hours")
    pick(session, "severity", "5")
    assert session.state == "chronic"
    outcome = DIALOG.handle_callback(session, {"k": "toggle", "f": "chronic", "v": "diabetes"})
    assert outcome.ack_keyboard is not None
    assert "✓ Диабет" in outcome.ack_text
    assert session.answers.chronic == ["diabetes"]
    done = DIALOG.handle_callback(session, {"k": "done", "f": "chronic", "v": ""})
    assert session.answers.chronic == ["diabetes"]
    assert "Шаг 9 из 14" in done.messages[0].text


def test_unknown_red_flag_is_recorded() -> None:
    session = make_session()
    start(session)
    DIALOG.handle_callback(session, {"k": "rf", "v": "unknown"})
    answer_flags(session)
    assert session.answers.red_unknown == ["chest_pain"]


def test_back_from_result_is_blocked() -> None:
    session = make_session()
    drive_to_complaint(session)
    complete_from_complaint(session)
    assert session.state == "result"
    back = nav(session, "back")
    assert session.state == "result"
    assert back.ack_text is not None and "устарела" in back.ack_text


def test_begin_after_result_starts_new_survey() -> None:
    session = make_session()
    drive_to_complaint(session)
    complete_from_complaint(session)
    nav(session, "help")
    begin = nav(session, "begin")
    assert session.state == "red_flags"
    assert "Признак 1 из 9" in begin.messages[0].text
    assert session.answers.category is None


def test_restart_clears_answers() -> None:
    session = make_session()
    drive_to_complaint(session)
    nav(session, "restart")
    assert session.state == "start"
    assert session.answers.category is None
    assert session.answers.chronic == []
    assert session.persisted is False


def test_full_text_dialog() -> None:
    session = make_session()
    DIALOG.welcome(session)
    DIALOG.handle_text(session, "начать")
    assert session.state == "red_flags"
    for _ in range(UNIVERSAL_COUNT):
        DIALOG.handle_text(session, "нет")
    assert session.state == "age"
    DIALOG.handle_text(session, "34")
    assert session.state == "sex"
    DIALOG.handle_text(session, "женский")
    assert session.state == "vital_flags"
    DIALOG.handle_text(session, "нет")
    assert session.state == "complaint"
    DIALOG.handle_text(session, "болит голова")
    assert session.state == "detail"
    DIALOG.handle_text(session, "голова")
    DIALOG.handle_text(session, "2 дня")
    DIALOG.handle_text(session, "5")
    assert session.state == "chronic"
    for _ in range(6):
        DIALOG.handle_text(session, "нет")
    assert session.state == "habits"
    DIALOG.handle_text(session, "пропустить")
    final = DIALOG.handle_text(session, "омс")
    assert session.state == "result"
    assert "невролог" in final[0].text
    assert "ОМС" in final[0].text
