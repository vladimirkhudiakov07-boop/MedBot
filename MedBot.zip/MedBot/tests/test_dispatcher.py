from __future__ import annotations

import json
from typing import Any

from app.database import Database
from app.dialog import Dialog
from app.dispatcher import Dispatcher
from app.sessions import SessionStore


class FakeClient:
    def __init__(self) -> None:
        self.sent: list[tuple[dict[str, int], str, dict | None]] = []
        self.answered: list[tuple[str, str]] = []

    async def send_message(
        self,
        target: dict[str, int],
        text: str,
        keyboard: dict | None = None,
        rate_key: str | None = None,
    ) -> dict:
        self.sent.append((target, text, keyboard))
        return {"message": {"body": {"mid": f"m{len(self.sent)}"}}}

    async def answer_callback(
        self,
        callback_id: str,
        text: str,
        keyboard: dict | None = None,
        rate_key: str | None = None,
    ) -> dict:
        self.answered.append((callback_id, text))
        return {"success": True}

    @property
    def texts(self) -> list[str]:
        return [text for _, text, _ in self.sent]


def make_dispatcher(
    max_text_length: int = 4000,
    user_messages_per_minute: int = 60,
    user_message_burst: int = 20,
    database: Database | None = None,
    admin_ids: frozenset[int] = frozenset(),
) -> tuple[Dispatcher, FakeClient, SessionStore]:
    client = FakeClient()
    store = SessionStore(ttl_seconds=600, history_limit=5)
    dispatcher = Dispatcher(
        client,
        store,
        Dialog(),
        database=database,
        admin_ids=admin_ids,
        max_text_length=max_text_length,
        user_messages_per_minute=user_messages_per_minute,
        user_message_burst=user_message_burst,
    )
    return dispatcher, client, store


async def make_dispatcher_with_db(
    tmp_path, admin_ids: frozenset[int] = frozenset()
) -> tuple[Dispatcher, FakeClient, SessionStore, Database]:
    database = Database(tmp_path / "test.sqlite3", "test-salt")
    await database.connect()
    dispatcher, client, store = make_dispatcher(
        database=database,
        admin_ids=admin_ids,
        user_messages_per_minute=600,
        user_message_burst=200,
    )
    return dispatcher, client, store, database


def message_update(
    text: str,
    mid: str = "m1",
    chat_type: str = "dialog",
    attachments: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "update_type": "message_created",
        "timestamp": 1,
        "message": {
            "sender": {"user_id": 1, "is_bot": False},
            "recipient": {"chat_id": 10, "chat_type": chat_type, "user_id": 1},
            "timestamp": 1,
            "body": {"mid": mid, "seq": 1, "text": text, "attachments": attachments or []},
        },
    }


def callback_update(payload: dict[str, Any], callback_id: str = "cb1") -> dict[str, Any]:
    return {
        "update_type": "message_callback",
        "timestamp": 1,
        "callback": {
            "timestamp": 1,
            "callback_id": callback_id,
            "payload": json.dumps(payload, ensure_ascii=False),
            "user": {"user_id": 1, "is_bot": False},
        },
        "message": {
            "sender": {"user_id": 0, "is_bot": True},
            "recipient": {"chat_id": 10, "chat_type": "dialog", "user_id": 1},
            "body": {"mid": "bot1", "seq": 1, "text": "вопрос"},
        },
    }


async def test_bot_started_sends_welcome() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update({"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}})
    assert len(client.sent) == 1
    assert "МедБот" in client.texts[0]
    assert client.sent[0][0] == {"user_id": 1}


async def test_bot_started_and_start_do_not_duplicate_welcome() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update({"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}})
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    assert len(client.sent) == 1


async def test_start_and_bot_started_do_not_duplicate_welcome() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update({"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}})
    assert len(client.sent) == 1


async def test_restart_after_welcome_sends_again() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update({"update_type": "bot_started", "chat_id": 10, "user": {"user_id": 1}})
    await dispatcher.handle_update(message_update("/restart", mid="m1"))
    assert len(client.sent) == 2


async def test_duplicate_update_is_ignored() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    assert len(client.sent) == 1


async def test_callback_answers_and_sends_next_question() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(callback_update({"k": "nav", "v": "begin"}))
    assert client.answered and client.answered[0][0] == "cb1"
    assert any("Признак 1 из 9" in text for text in client.texts)


async def test_text_answer_is_accepted() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(callback_update({"k": "nav", "v": "begin"}))
    for index in range(9):
        await dispatcher.handle_update(message_update("нет", mid=f"flag-{index}"))
    await dispatcher.handle_update(message_update("34", mid="age"))
    assert any("Шаг 2 из 15" in text for text in client.texts)


async def test_audio_message_gets_hint() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(
        message_update("", mid="m2", attachments=[{"type": "audio", "payload": {"token": "t"}}])
    )
    assert any("голосовые" in text.lower() for text in client.texts)


async def test_group_chat_gets_private_chat_hint() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("привет", mid="m1", chat_type="chat"))
    assert client.sent
    assert "личном чате" in client.texts[0]


async def test_group_callback_does_not_start_survey() -> None:
    dispatcher, client, _ = make_dispatcher()
    update = callback_update({"k": "nav", "v": "begin"})
    update["message"]["recipient"]["chat_type"] = "chat"
    await dispatcher.handle_update(update)
    assert client.answered
    assert "личном чате" in client.answered[0][1]
    assert not client.sent


async def test_callback_with_deleted_message_is_answered_only() -> None:
    dispatcher, client, _ = make_dispatcher()
    update = callback_update({"k": "nav", "v": "begin"})
    update["message"] = None
    await dispatcher.handle_update(update)
    assert client.answered
    assert "устарела" in client.answered[0][1]
    assert not client.sent


async def test_photo_without_text_gets_attachment_hint() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(
        message_update("", mid="m2", attachments=[{"type": "image", "payload": {"photo_id": 1}}])
    )
    assert any("только текст" in text.lower() for text in client.texts)


async def test_stop_command_says_goodbye_and_drops_session() -> None:
    dispatcher, client, store = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    assert store.size == 1
    await dispatcher.handle_update(message_update("/stop", mid="m2"))
    assert any("Остановил опрос" in text for text in client.texts)
    assert store.size == 0


async def test_emergency_message_sent_for_text_flag() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(message_update("сильно болит грудь", mid="m2"))
    assert any("103" in text for text in client.texts)


async def test_dialog_cleared_drops_session() -> None:
    dispatcher, _client, store = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    assert store.size == 1
    await dispatcher.handle_update(
        {"update_type": "dialog_cleared", "chat_id": 10, "user": {"user_id": 1}, "timestamp": 2}
    )
    assert store.size == 0


async def test_duplicate_update_id_is_ignored() -> None:
    dispatcher, client, _ = make_dispatcher()
    first = message_update("/start", mid="m1")
    first["update_id"] = "upd-1"
    second = message_update("/start", mid="m2")
    second["update_id"] = "upd-1"
    await dispatcher.handle_update(first)
    await dispatcher.handle_update(second)
    assert len(client.sent) == 1


async def test_long_text_is_rejected_before_nlu() -> None:
    dispatcher, client, _ = make_dispatcher(max_text_length=100)
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(message_update("я" * 101, mid="m2"))
    assert any("слишком длинное" in text for text in client.texts)


async def test_user_rate_limit_drops_extra_messages() -> None:
    dispatcher, client, _ = make_dispatcher(user_messages_per_minute=1, user_message_burst=1)
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    await dispatcher.handle_update(message_update("34", mid="m2"))
    assert len(client.sent) == 1


async def test_callback_with_mismatched_user_is_not_trusted() -> None:
    dispatcher, client, _ = make_dispatcher()
    await dispatcher.handle_update(message_update("/start", mid="m1"))
    update = callback_update({"k": "nav", "v": "begin"})
    update["callback"]["user"]["user_id"] = 2
    await dispatcher.handle_update(update)
    assert client.answered
    assert "устарела" in client.answered[0][1]
    assert not any("Признак 1 из 9" in text for text in client.texts)


async def complete_survey(dispatcher: Dispatcher) -> None:
    await dispatcher.handle_update(message_update("/start", mid="start"))
    await dispatcher.handle_update(callback_update({"k": "nav", "v": "begin"}, "cb-begin"))
    for index in range(9):
        await dispatcher.handle_update(callback_update({"k": "rf", "v": "no"}, f"cb-rf-{index}"))
    steps: list[dict[str, str]] = [
        {"k": "pick", "f": "age", "v": "adult"},
        {"k": "pick", "f": "sex", "v": "male"},
        {"k": "pick", "f": "complaint", "v": "pain"},
        {"k": "pick", "f": "detail", "v": "chest"},
        {"k": "pick", "f": "duration", "v": "hours"},
        {"k": "pick", "f": "severity", "v": "5"},
        {"k": "done", "f": "chronic", "v": ""},
        {"k": "pick", "f": "meds", "v": "none"},
        {"k": "pick", "f": "allergies", "v": "none"},
        {"k": "pick", "f": "surgery", "v": "no"},
        {"k": "done", "f": "heredity", "v": ""},
        {"k": "pick", "f": "habits", "v": "skip"},
        {"k": "pick", "f": "payment", "v": "oms"},
    ]
    for index, payload in enumerate(steps):
        await dispatcher.handle_update(callback_update(payload, f"cb-step-{index}"))


async def test_completed_survey_is_saved_and_shown_in_history(tmp_path) -> None:
    dispatcher, client, _, database = await make_dispatcher_with_db(tmp_path)
    await complete_survey(dispatcher)
    items = await database.history("u1")
    assert len(items) == 1
    assert items[0].specialty == "кардиолог"
    await dispatcher.handle_update(message_update("/history", mid="history"))
    assert any("кардиолог" in text for text in client.texts)
    client.sent.clear()
    await dispatcher.handle_update(callback_update({"k": "nav", "v": "history"}, "cb-history"))
    assert any("кардиолог" in text for text in client.texts)
    await database.close()


async def test_stats_available_to_admin(tmp_path) -> None:
    dispatcher, client, _, database = await make_dispatcher_with_db(
        tmp_path, admin_ids=frozenset({1})
    )
    await complete_survey(dispatcher)
    await dispatcher.handle_update(message_update("/stats", mid="stats"))
    assert any("Статистика обращений" in text for text in client.texts)
    client.sent.clear()
    await dispatcher.handle_update(callback_update({"k": "nav", "v": "stats"}, "cb-stats"))
    assert any("Статистика обращений" in text for text in client.texts)
    await database.close()


async def test_stats_denied_to_regular_user(tmp_path) -> None:
    dispatcher, client, _, database = await make_dispatcher_with_db(tmp_path)
    await dispatcher.handle_update(message_update("/stats", mid="stats"))
    assert any("доступна администратору" in text for text in client.texts)
    await database.close()


async def test_forget_removes_user_history(tmp_path) -> None:
    dispatcher, client, _, database = await make_dispatcher_with_db(tmp_path)
    await complete_survey(dispatcher)
    assert await database.history("u1")
    await dispatcher.handle_update(message_update("/forget", mid="forget"))
    assert any("Удалено обращений" in text for text in client.texts)
    assert await database.history("u1") == []
    await database.close()

