from __future__ import annotations

import pytest

from app import texts
from app.models import Answers
from app.triage import Place, Urgency, evaluate


def make(**kwargs: object) -> Answers:
    answers = Answers()
    for name, value in kwargs.items():
        setattr(answers, name, value)
    return answers


@pytest.mark.parametrize(
    "flag",
    [
        "chest_pain",
        "dyspnea_rest",
        "syncope",
        "seizure",
        "bleeding",
        "stroke",
        "anaphylaxis",
        "severe_abdomen",
        "head_injury",
        "child_fever",
        "pregnancy_bleeding",
    ],
)
def test_each_red_flag_is_emergency(flag: str) -> None:
    result = evaluate(make(red_flags=[flag]))
    assert result.urgency is Urgency.EMERGENCY
    assert result.place is Place.AMBULANCE
    assert result.signals


def test_child_high_fever_is_emergency_without_explicit_flag() -> None:
    result = evaluate(make(age=5, category="fever", detail="critical", severity=5, duration="hours"))
    assert result.urgency is Urgency.EMERGENCY
    assert "child_fever" in {signal.key for signal in result.signals}


def test_chest_pain_routes_to_cardiologist() -> None:
    result = evaluate(make(age=40, category="pain", detail="chest", severity=7, duration="hours"))
    assert result.urgency is Urgency.URGENT_24H
    assert result.specialty == "кардиолог"
    assert result.place is Place.EMERGENCY_ROOM
    assert any("грудь" in reason.lower() for reason in result.reasons)


def test_infant_fever_is_urgent() -> None:
    result = evaluate(make(age=0, category="fever", detail="mid", severity=5, duration="hours"))
    assert result.urgency is Urgency.URGENT_24H


def test_unknown_red_flag_is_urgent() -> None:
    result = evaluate(
        make(age=30, category="skin", detail="itch", severity=2, duration="4-7d", red_unknown=["chest_pain"])
    )
    assert result.urgency is Urgency.URGENT_24H


def test_oncology_with_fever_is_urgent() -> None:
    result = evaluate(
        make(age=55, category="fever", detail="mid", severity=5, duration="hours", chronic=["oncology"])
    )
    assert result.urgency is Urgency.URGENT_24H


def test_severe_abdominal_pain_goes_to_surgeon_and_emergency_room() -> None:
    result = evaluate(
        make(age=30, category="pain", detail="abdomen", detail_label="Живот", severity=8, duration="1-3d")
    )
    assert result.urgency is Urgency.URGENT_24H
    assert result.specialty == "хирург"
    assert result.place is Place.EMERGENCY_ROOM


def test_mild_skin_itch_is_self_care() -> None:
    result = evaluate(make(age=25, category="skin", detail="itch", detail_label="Зуд", severity=2, duration="4-7d"))
    assert result.urgency is Urgency.SELF_CARE
    assert result.specialty == "дерматолог"
    assert result.place is Place.PHARMACY


def test_pregnancy_routes_to_obstetrician() -> None:
    result = evaluate(
        make(
            age=28,
            sex="female",
            pregnancy="pregnant",
            category="pain",
            detail="abdomen",
            detail_label="Живот",
            severity=6,
            duration="hours",
        )
    )
    assert result.urgency is Urgency.URGENT_24H
    assert result.specialty == "акушер-гинеколог"


def test_child_trauma_routes_to_pediatric_surgeon() -> None:
    result = evaluate(make(age=8, category="trauma", detail="limb", severity=5, duration="hours"))
    assert result.specialty == "детский хирург"


def test_neurological_deficit_is_urgent() -> None:
    result = evaluate(make(age=60, category="neuro", detail="numbness", severity=6, duration="hours"))
    assert result.urgency is Urgency.URGENT_24H
    assert result.specialty == "невролог"


def test_adult_high_fever_is_urgent() -> None:
    result = evaluate(make(age=35, category="fever", detail="critical", severity=5, duration="hours"))
    assert result.urgency is Urgency.URGENT_24H
    assert result.specialty == "терапевт"


def test_lactating_woman_with_skin_issue_goes_to_dermatologist() -> None:
    result = evaluate(
        make(age=30, sex="female", pregnancy="lactating", category="skin", detail="rash", severity=4, duration="1-3d")
    )
    assert result.specialty == "дерматолог"


def test_pregnancy_chest_pain_goes_to_cardiologist() -> None:
    result = evaluate(
        make(
            age=30,
            sex="female",
            pregnancy="pregnant",
            category="pain",
            detail="chest",
            severity=7,
            duration="hours",
        )
    )
    assert result.specialty == "кардиолог"


def test_emergency_text_has_ambulance_numbers() -> None:
    result = evaluate(make(red_flags=["chest_pain"]))
    text = texts.emergency_text(result)
    assert "103" in text and "112" in text
    assert "не ставлю диагноз" in text.lower()


def test_result_text_contains_disclaimer_and_route() -> None:
    answers = make(
        age=40,
        category="pain",
        detail="chest",
        detail_label="Грудь",
        severity=7,
        duration="hours",
        payment="oms",
    )
    result = evaluate(answers)
    text = texts.result_text(result, answers)
    assert "Итог опроса" in text
    assert "кардиолог" in text
    assert "103" in text and "112" in text
    assert "ОМС" in text
    assert "не диагноз" in text.lower() or "это не диагноз" in text.lower()
