from __future__ import annotations

import time

from app import texts
from app.database import Stats
from app.models import Answers, HistoryItem
from app.triage import Place, Urgency, evaluate


def answers(**kwargs: object) -> Answers:
    result = Answers()
    for name, value in kwargs.items():
        setattr(result, name, value)
    return result


def history_item(urgency: str, specialty: str) -> HistoryItem:
    return HistoryItem(time.time(), urgency, specialty, "clinic")


CASES = [
    texts.start_text(),
    texts.help_text(),
    texts.audio_hint(),
    texts.unknown_hint(),
    texts.text_too_long(4000),
    texts.farewell_text(),
    texts.card_hint(),
    texts.group_hint(),
    texts.script_text(),
    texts.history_text([]),
    texts.stats_text(
        Stats(
            total_requests=2,
            unique_users=1,
            emergency=1,
            urgent=1,
            planned=0,
            self_care=0,
            started=2,
            completed=2,
            by_specialty=(("кардиолог", 2),),
            by_day=(("25.11", 2),),
        )
    ),
    texts.stats_denied_text(),
    texts.forget_text(1),
    texts.forget_text(0),
    texts.emergency_text(evaluate(answers(red_flags=["chest_pain"]))),
]


def test_markdown_markers_are_balanced() -> None:
    for text in CASES:
        assert text.count("**") % 2 == 0, text


def test_result_card_sections() -> None:
    values = answers(
        age=40,
        category="pain",
        detail="chest",
        detail_label="Грудь",
        severity=7,
        duration="hours",
        payment="dms",
    )
    result = evaluate(values)
    text = texts.result_text(result, values)
    assert text.count("**") % 2 == 0
    assert "Срочность" in text
    assert "Куда обратиться" in text
    assert "Врач" in text
    assert "Почему такой вывод" in text
    assert "Что сделать сейчас" in text
    assert "ДМС" in text
    assert "103" in text and "112" in text


def test_result_card_has_no_prescriptions() -> None:
    values = answers(age=30, category="skin", detail="itch", severity=2, duration="4-7d")
    text = texts.result_text(evaluate(values), values)
    lowered = text.lower()
    for forbidden in ("мг", "таблетк", "принимайте", "дозировк", "антибиотик"):
        assert forbidden not in lowered


def test_history_lists_entries() -> None:
    entries = [history_item("emergency", "кардиолог"), history_item("planned", "терапевт")]
    text = texts.history_text(entries)
    assert "экстренно" in text
    assert "кардиолог" in text


def test_stats_text_contains_totals() -> None:
    text = texts.stats_text(
        Stats(
            total_requests=3,
            unique_users=2,
            emergency=1,
            urgent=1,
            planned=1,
            self_care=0,
            started=4,
            completed=3,
            by_specialty=(("кардиолог", 2),),
            by_day=(("25.11", 3),),
        )
    )
    assert "3" in text
    assert "кардиолог" in text
    assert "25.11" in text


def test_self_care_card_points_to_pharmacy_or_telemedicine() -> None:
    values = answers(age=30, category="skin", detail="itch", severity=2, duration="4-7d")
    result = evaluate(values)
    assert result.urgency is Urgency.SELF_CARE
    assert result.place in {Place.PHARMACY, Place.TELEMEDICINE}
