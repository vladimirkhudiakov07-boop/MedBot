from __future__ import annotations

import time

from app.sessions import SessionStore


def test_store_evicts_least_recently_used_session() -> None:
    store = SessionStore(ttl_seconds=600, max_sessions=2, max_age_seconds=3600)
    store.get_or_create("u1", 1, 1)
    store.get_or_create("u2", 2, 2)
    store.get("u1")
    store.get_or_create("u3", 3, 3)
    assert store.get("u2") is None
    assert store.get("u1") is not None
    assert store.get("u3") is not None
    assert store.size == 2


def test_store_drops_session_after_absolute_max_age() -> None:
    store = SessionStore(ttl_seconds=600, max_sessions=10, max_age_seconds=300)
    session = store.get_or_create("u1", 1, 1)
    session.created_at = time.time() - 301
    assert store.cleanup() == 1
    assert store.size == 0


def test_store_drops_session_after_idle_ttl() -> None:
    store = SessionStore(ttl_seconds=600, max_sessions=10, max_age_seconds=3600)
    session = store.get_or_create("u1", 1, 1)
    session.updated_at = time.time() - 601
    assert store.cleanup() == 1
    assert store.size == 0
