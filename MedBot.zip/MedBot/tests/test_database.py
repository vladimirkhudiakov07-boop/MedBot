from __future__ import annotations

from app.database import Database
from app.models import Answers
from app.triage import evaluate


async def test_save_history_stats_and_delete(tmp_path) -> None:
    database = Database(tmp_path / "bot.sqlite3", "test-salt")
    await database.connect()
    answers = Answers(
        age=40,
        category="pain",
        detail="chest",
        detail_label="Грудь",
        severity=7,
        duration="hours",
        payment="oms",
    )
    await database.log_event("u1", "survey_started")
    await database.save_request("u1", answers, evaluate(answers), 0)

    items = await database.history("u1")
    assert len(items) == 1
    assert items[0].specialty == "кардиолог"
    assert items[0].urgency == "urgent_24h"

    stats = await database.stats()
    assert stats.total_requests == 1
    assert stats.unique_users == 1
    assert stats.urgent == 1
    assert stats.started == 1
    assert stats.completed == 1
    assert stats.by_specialty == (("кардиолог", 1),)

    assert await database.delete_history("u1") == 1
    assert await database.history("u1") == []
    await database.close()


async def test_salt_persists_between_restarts(tmp_path) -> None:
    path = tmp_path / "bot.sqlite3"
    first = Database(path)
    await first.connect()
    first_hash = first.user_hash("u1")
    await first.close()
    assert (tmp_path / ".history_salt").is_file()

    second = Database(path)
    await second.connect()
    assert second.user_hash("u1") == first_hash
    await second.close()
