from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class Answers:
    age: int | None = None
    age_label: str = ""
    sex: str | None = None
    category: str | None = None
    detail: str | None = None
    detail_label: str = ""
    duration: str | None = None
    severity: int | None = None
    chronic: list[str] = field(default_factory=list)
    meds: str | None = None
    allergies: str | None = None
    surgery: bool | None = None
    heredity: list[str] = field(default_factory=list)
    pregnancy: str | None = None
    habits: str | None = None
    payment: str | None = None
    red_flags: list[str] = field(default_factory=list)
    red_unknown: list[str] = field(default_factory=list)
    tokens: set[str] = field(default_factory=set)

    def clone(self) -> Answers:
        return copy.deepcopy(self)


@dataclass(frozen=True, slots=True)
class Outgoing:
    text: str
    keyboard: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class ReplyTarget:
    chat_id: int | None = None
    user_id: int | None = None
    dialog: bool = True
    key: str = ""

    @classmethod
    def from_message(cls, message: dict[str, Any]) -> ReplyTarget:
        recipient = message.get("recipient") or {}
        sender = message.get("sender") or {}
        chat_type = recipient.get("chat_type")
        chat_id = recipient.get("chat_id")
        user_id = sender.get("user_id") or recipient.get("user_id")
        if chat_type == "dialog":
            key = f"u{user_id or chat_id}"
            return cls(chat_id=chat_id, user_id=user_id, dialog=True, key=key)
        key = f"c{chat_id}"
        return cls(chat_id=chat_id, user_id=None, dialog=False, key=key)

    @classmethod
    def from_update(cls, update: dict[str, Any]) -> ReplyTarget:
        user = update.get("user") or {}
        chat_id = update.get("chat_id")
        user_id = user.get("user_id")
        if user_id is not None:
            return cls(chat_id=chat_id, user_id=user_id, dialog=True, key=f"u{user_id}")
        return cls(chat_id=chat_id, user_id=None, dialog=False, key=f"c{chat_id}")

    def params(self) -> dict[str, int]:
        if self.user_id is not None:
            return {"user_id": self.user_id}
        if self.chat_id is not None:
            return {"chat_id": self.chat_id}
        raise ValueError("пустой адрес получателя")


@dataclass(frozen=True, slots=True)
class HistoryItem:
    at: float
    urgency: str
    specialty: str
    place: str
