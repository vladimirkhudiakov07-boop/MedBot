from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import texts
from app.config import Settings, load_settings
from app.database import Database
from app.dialog import Dialog
from app.dispatcher import Dispatcher
from app.instance_lock import InstanceLock
from app.max_api import MaxApiError, MaxClient
from app.server import run_polling, run_webhook
from app.sessions import SessionStore

log = logging.getLogger(__name__)


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("aiohttp.client").setLevel(logging.WARNING)


async def run() -> None:
    settings = load_settings(Path(__file__).resolve().parents[1] / ".env")
    configure_logging(settings.log_level)
    lock = InstanceLock(Path(settings.db_path).parent / "medbot.lock")
    if not lock.acquire():
        log.error(
            "Бот уже запущен другим процессом. Остановите его перед повторным запуском "
            "(блокировка: %s).",
            Path(settings.db_path).parent / "medbot.lock",
        )
        raise SystemExit(4)
    try:
        await _run(settings)
    finally:
        lock.release()


async def _run(settings: Settings) -> None:
    if settings.insecure_ssl:
        log.warning("MAX_INSECURE_SSL=1: проверка TLS отключена, не используйте это в production")
    client = MaxClient(settings)
    async with client:
        try:
            me = await client.get_me()
        except MaxApiError as exc:
            log.error("не удалось подключиться к MAX API: %s", exc)
            raise SystemExit(2) from exc
        log.info("бот %s (@%s), режим %s", me.get("name", "?"), me.get("username", "?"), settings.mode)
        try:
            await client.set_commands(texts.COMMANDS)
        except MaxApiError as exc:
            log.warning("команды бота не обновлены: %s", exc)
        store = SessionStore(
            settings.session_ttl,
            settings.history_limit,
            max_sessions=settings.max_sessions,
            max_age_seconds=settings.session_max_age,
        )
        store.start_cleanup()
        database = Database(settings.db_path, settings.db_salt)
        await database.connect()
        dialog = Dialog()
        dispatcher = Dispatcher(
            client,
            store,
            dialog,
            database=database,
            admin_ids=settings.admin_ids,
            max_text_length=settings.max_text_length,
            user_messages_per_minute=settings.user_messages_per_minute,
            user_message_burst=settings.user_message_burst,
        )
        try:
            if settings.mode == "webhook":
                await run_webhook(client, dispatcher, settings)
            else:
                await ensure_long_polling_available(client)
                await run_polling(client, dispatcher, settings)
        finally:
            await store.close()
            await database.close()


async def ensure_long_polling_available(client: MaxClient) -> None:
    try:
        subscriptions = await client.get_subscriptions()
    except MaxApiError as exc:
        log.warning("не удалось проверить webhook-подписки: %s", exc)
        return
    if not subscriptions:
        return
    urls = ", ".join(str(item.get("url", "?")) for item in subscriptions)
    log.error(
        "найдена активная webhook-подписка (%s): long polling не получит события. "
        "Удалите подписку или включите BOT_MODE=webhook",
        urls,
    )
    raise SystemExit(3)


def main() -> None:
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        log.info("остановлено пользователем")


if __name__ == "__main__":
    main()
