from __future__ import annotations

from dataclasses import dataclass

from .models import Answers


@dataclass(frozen=True, slots=True)
class RedFlagQuestion:
    key: str
    title: str
    question: str
    hint: str


CHEST_PAIN = RedFlagQuestion(
    "chest_pain",
    "боль в груди",
    "Есть ли боль или давление в груди, за грудиной, отдающее в руку, шею или спину?",
    "Такая боль может быть признаком проблем с сердцем.",
)
DYSPNEA = RedFlagQuestion(
    "dyspnea_rest",
    "одышка в покое",
    "Есть ли одышка в покое или ощущение, что не хватает воздуха?",
    "Речь о дыхании, которое затруднено, даже когда вы сидите или лежите.",
)
SYNCOPE = RedFlagQuestion(
    "syncope",
    "потеря сознания",
    "Была ли потеря сознания или обморок, даже кратковременный?",
    "Внезапное отключение сознания — повод для экстренной помощи.",
)
SEIZURE = RedFlagQuestion(
    "seizure",
    "судороги",
    "Были ли судороги или приступ, похожий на эпилептический?",
    "Судороги требуют немедленного осмотра врача.",
)
BLEEDING = RedFlagQuestion(
    "bleeding",
    "кровотечение",
    "Есть ли кровотечение, которое не останавливается, или рвота и стул с кровью?",
    "Сильное или неостанавливающееся кровотечение опасно для жизни.",
)
STROKE = RedFlagQuestion(
    "stroke",
    "признаки инсульта",
    "Есть ли перекос лица, слабость или онемение в руке или ноге, нарушение речи или зрения?",
    "Это признаки инсульта: помощь нужна в первые минуты.",
)
ANAPHYLAXIS = RedFlagQuestion(
    "anaphylaxis",
    "признаки анафилаксии",
    "Опухают ли губы, язык или горло, трудно ли глотать или дышать?",
    "Отёк горла и затруднённое дыхание — угроза жизни.",
)
SEVERE_ABDOMEN = RedFlagQuestion(
    "severe_abdomen",
    "острая боль в животе",
    "Есть ли резкая, невыносимая боль в животе или живот стал твёрдым?",
    "Острая боль в животе может требовать операции.",
)
HEAD_INJURY = RedFlagQuestion(
    "head_injury",
    "травма головы с потерей сознания",
    "Была ли травма головы с потерей сознания или сильным ударом?",
    "После такой травмы нужен осмотр врача, даже если стало легче.",
)
CHILD_FEVER = RedFlagQuestion(
    "child_fever",
    "высокая температура у ребёнка",
    "Температура у ребёнка выше 39,5 °C?",
    "У детей такая температура требует медицинской оценки.",
)
PREGNANCY_BLEEDING = RedFlagQuestion(
    "pregnancy_bleeding",
    "кровотечение при беременности",
    "Есть ли кровянистые выделения или сильная боль в животе при беременности?",
    "При беременности это повод срочно обратиться за помощью.",
)

UNIVERSAL_QUESTIONS: tuple[RedFlagQuestion, ...] = (
    CHEST_PAIN,
    DYSPNEA,
    SYNCOPE,
    SEIZURE,
    BLEEDING,
    STROKE,
    ANAPHYLAXIS,
    SEVERE_ABDOMEN,
    HEAD_INJURY,
)


def age_specific_questions(answers: Answers) -> list[RedFlagQuestion]:
    questions: list[RedFlagQuestion] = []
    if answers.age is not None and answers.age < 18:
        questions.append(CHILD_FEVER)
    if answers.pregnancy in {"pregnant", "lactating"} or (answers.sex == "female" and answers.age is not None and 12 <= answers.age <= 55):
        questions.append(PREGNANCY_BLEEDING)
    return questions
