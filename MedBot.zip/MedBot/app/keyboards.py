from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any

MAX_TEXT = 128
MAX_PAYLOAD = 1024
MAX_ROWS = 30
MAX_ROW_BUTTONS = 7


class KeyboardError(ValueError):
    pass


def encode_payload(data: dict[str, Any]) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    if len(raw) > MAX_PAYLOAD:
        raise KeyboardError("payload кнопки превышает ограничение MAX")
    return raw


def decode_payload(raw: str | None) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return {"k": "text", "v": raw}
    return data if isinstance(data, dict) else {"k": "text", "v": raw}


def callback_button(text: str, payload: dict[str, Any]) -> dict[str, Any]:
    if not text:
        raise KeyboardError("текст кнопки не может быть пустым")
    return {"type": "callback", "text": text[:MAX_TEXT], "payload": encode_payload(payload)}


def link_button(text: str, url: str) -> dict[str, Any]:
    return {"type": "link", "text": text[:MAX_TEXT], "url": url}


SPECIAL_BUTTONS = {"link", "open_app", "request_geo_location", "request_contact"}


def inline_keyboard(rows: Sequence[Sequence[dict[str, Any]]]) -> dict[str, Any]:
    cleaned = [list(row) for row in rows if row]
    if not cleaned:
        raise KeyboardError("клавиатура не может быть пустой")
    if len(cleaned) > MAX_ROWS:
        raise KeyboardError("слишком много рядов кнопок")
    for row in cleaned:
        if len(row) > MAX_ROW_BUTTONS:
            raise KeyboardError("слишком много кнопок в ряду")
        if len(row) > 3 and any(button.get("type") in SPECIAL_BUTTONS for button in row):
            raise KeyboardError("в ряду с особыми кнопками допускается не больше трёх кнопок")
    return {"type": "inline_keyboard", "payload": {"buttons": cleaned}}


def chunk(options: Sequence[tuple[str, str]], per_row: int) -> list[list[tuple[str, str]]]:
    if not 1 <= per_row <= MAX_ROW_BUTTONS:
        raise KeyboardError("недопустимое число кнопок в ряду")
    rows: list[list[tuple[str, str]]] = []
    for index in range(0, len(options), per_row):
        rows.append(list(options[index : index + per_row]))
    return rows
