from __future__ import annotations

import re
from difflib import SequenceMatcher

from .options import ALLERGIES, CHRONIC, DETAILS, DURATIONS, HABITS, HEREDITY, MEDS, PAYMENT, PREGNANCY, SEX

_WORD_RE = re.compile(r"[a-zа-я0-9]+")
_NEGATIONS = {"не", "нет", "без", "ни", "никогда", "отсутствует", "отрицаю"}

_NUMBER_WORDS = {
    "ноль": 0,
    "один": 1,
    "одна": 1,
    "два": 2,
    "две": 2,
    "три": 3,
    "четыре": 4,
    "пять": 5,
    "шесть": 6,
    "семь": 7,
    "восемь": 8,
    "девять": 9,
    "десять": 10,
    "одиннадцать": 11,
    "двенадцать": 12,
    "тринадцать": 13,
    "четырнадцать": 14,
    "пятнадцать": 15,
    "шестнадцать": 16,
    "семнадцать": 17,
    "восемнадцать": 18,
    "девятнадцать": 19,
    "двадцать": 20,
    "тридцать": 30,
    "сорок": 40,
    "пятьдесят": 50,
    "шестьдесят": 60,
    "семьдесят": 70,
    "восемьдесят": 80,
    "девяносто": 90,
}

_SYNONYMS: dict[str, tuple[str, ...]] = {
    "headache": ("головная боль", "болит голова", "голова болит", "мигрень", "давит на голову"),
    "dizziness": ("головокружение", "кружится голова", "голова кружится", "дурнота"),
    "chest": ("боль в груди", "болит грудь", "давит в груди", "за грудиной", "в области сердца", "сжимает грудь", "жжет в груди", "боль в сердце"),
    "abdomen": ("боль в животе", "болит живот", "живот болит", "резь в животе", "под ложечкой", "в правом боку", "в левом боку", "внизу живота"),
    "back": ("боль в спине", "болит спина", "поясница", "в пояснице", "ломит спину"),
    "limb": ("болит нога", "болят ноги", "болит рука", "болят руки", "колено", "локоть", "сустав", "лодыжка", "плечо", "бедро"),
    "throat": ("боль в горле", "болит горло", "першение", "ангина", "горло"),
    "ear": ("болит ухо", "ухо", "заложило ухо", "отит"),
    "nose": ("насморк", "заложен нос", "сопли"),
    "voice": ("осип", "пропал голос", "хриплый голос"),
    "tooth": ("зуб", "зубная боль", "десна", "болят зубы", "болит зуб"),
    "eye": ("глаз", "зрение", "в глазу", "покраснение глаза", "двоится"),
    "fever": ("температура", "жар", "лихорадка", "озноб", "37", "38", "39"),
    "cough": ("кашель", "кашляю", "першит"),
    "dyspnea": ("одышка", "нехватка воздуха", "не хватает воздуха", "тяжело дышать", "задыхаюсь", "удушье"),
    "nausea": ("тошнит", "тошнота", "рвота", "рвет"),
    "diarrhea": ("понос", "диарея", "жидкий стул"),
    "constipation": ("запор", "не могу сходить в туалет"),
    "heartburn": ("изжога", "жжет в желудке", "кислый привкус"),
    "rash": ("сыпь", "высыпания", "крапивница", "пятна"),
    "itch": ("зуд", "чешется", "зудят"),
    "skin_red": ("покраснение", "краснота", "воспаление кожи"),
    "swelling": ("отек", "опухло", "припухлость", "отекла"),
    "wound": ("рана", "порез", "гной", "нарыв", "ссадина"),
    "numbness": ("онемение", "онемела", "немеет", "покалывание"),
    "speech": ("нарушение речи", "не могу говорить", "заплетается язык", "невнятная речь"),
    "seizure": ("судороги", "припадок", "эпилепсия"),
    "tremor": ("тремор", "дрожь", "трясет"),
    "trauma": ("травма", "упал", "удар", "перелом", "вывих", "растяжение", "ушиб", "подвернул"),
    "bleeding": ("кровотечение", "кровь", "кровит", "кровь идет"),
    "anxiety": ("тревога", "паника", "паническая атака", "депрессия", "бессонница", "стресс", "нервы"),
    "burn": ("ожог", "обжег", "обжегся"),
    "pain": ("боль", "болит", "болят", "боли", "ноет", "режет", "колет", "тянет"),
}

_CATEGORY_TOKENS: tuple[tuple[str, frozenset[str]], ...] = (
    ("trauma", frozenset({"trauma", "wound", "burn"})),
    ("fever", frozenset({"fever"})),
    ("breathing", frozenset({"dyspnea", "cough"})),
    ("neuro", frozenset({"numbness", "speech", "seizure", "tremor", "dizziness"})),
    ("gi", frozenset({"nausea", "diarrhea", "constipation", "heartburn"})),
    ("skin", frozenset({"rash", "itch", "skin_red", "swelling"})),
    ("ent", frozenset({"throat", "ear", "nose", "voice"})),
    ("pain", frozenset({"headache", "chest", "abdomen", "back", "limb", "tooth", "pain"})),
)

_PAIN_DETAILS: tuple[tuple[str, frozenset[str]], ...] = (
    ("chest", frozenset({"chest"})),
    ("abdomen", frozenset({"abdomen"})),
    ("head", frozenset({"headache"})),
    ("face", frozenset({"tooth"})),
    ("throat", frozenset({"throat"})),
    ("ear", frozenset({"ear"})),
    ("back", frozenset({"back"})),
    ("limb", frozenset({"limb"})),
)

_RED_FLAGS: dict[str, tuple[str, ...]] = {
    "chest_pain": ("боль в груди", "болит грудь", "давит в груди", "сжимает грудь", "боль за грудиной", "отдает в левую руку", "боль в сердце", "жжет в груди"),
    "dyspnea_rest": ("одышка в покое", "не могу дышать", "не хватает воздуха", "задыхаюсь", "удушье", "тяжело дышать", "нечем дышать"),
    "syncope": ("потеря сознания", "потерял сознание", "упал в обморок", "обморок", "отключился", "терял сознание"),
    "seizure": ("судороги", "припадок", "эпилепсия"),
    "bleeding": ("кровотечение", "кровь не останавливается", "сильное кровотечение", "рвота кровью", "кровь в стуле", "кровит"),
    "stroke": ("онемела", "онемение половины", "перекосило", "не могу говорить", "нарушение речи", "не вижу", "слабость в руке", "слабость в ноге", "асимметрия лица", "опустился угол рта"),
    "anaphylaxis": ("отек горла", "отекли губы", "отек языка", "не могу глотать", "анафилаксия", "отек лица", "отек шеи"),
    "severe_abdomen": ("сильная боль в животе", "острая боль в животе", "невыносимая боль в животе", "живот твердый", "живот как камень"),
    "head_injury": ("травма головы", "сотрясение", "потеря сознания после удара", "сильный удар по голове"),
    "pregnancy_bleeding": ("кровотечение при беременности", "кровянистые выделения при беременности", "мажущие выделения при беременности"),
    "child_fever": ("у ребенка температура 39", "ребенок температура 39", "у ребенка температура 40"),
}

_YES = {"да", "конечно", "есть", "ага", "yes", "точно", "было", "был", "была", "были", "бывает", "перенес", "делали"}
_NO = {"нет", "нету", "no", "отсутствует", "никогда", "неа"}
_UNKNOWN = {"не знаю", "незнаю", "затрудняюсь", "может", "не помню", "хз", "не уверен"}
_CONTINUATION = {
    "проходит",
    "прошло",
    "прошла",
    "отпускает",
    "прекращается",
    "перестает",
    "перестаёт",
    "утихает",
    "исчезает",
    "снимается",
    "останавливается",
}


def normalize(text: str) -> str:
    lowered = (text or "").lower().replace("ё", "е")
    lowered = re.sub(r"[^a-zа-я0-9]+", " ", lowered)
    return re.sub(r"\s+", " ", lowered).strip()


def tokens(text: str) -> list[str]:
    return _WORD_RE.findall(normalize(text))


def _same_word(left: str, right: str) -> bool:
    if left == right:
        return True
    if min(len(left), len(right)) < 4:
        return False
    if abs(len(left) - len(right)) > 3:
        return False
    if left[:4] == right[:4]:
        return True
    return SequenceMatcher(None, left, right).ratio() >= 0.84


def _continues(words: list[str], start: int, stop: int) -> bool:
    for index in range(max(0, start), min(stop, len(words))):
        if any(_same_word(words[index], verb) for verb in _CONTINUATION):
            return True
    return False


def _negated(words: list[str], start: int, end: int) -> bool:
    for index in range(max(0, start - 2), start):
        if words[index] in _NEGATIONS and not _continues(words, index + 1, start):
            return True
    for index in range(end, min(len(words), end + 2)):
        if words[index] in _NEGATIONS:
            if index == end and _continues(words, index + 1, index + 2):
                continue
            return True
    return False


def _phrase_matches(phrase: str, words: list[str], start: int) -> bool:
    parts = phrase.split()
    if start + len(parts) > len(words):
        return False
    return all(_same_word(words[start + offset], part) for offset, part in enumerate(parts))


def _find_phrase(phrase: str, words: list[str], allow_negation: bool = True) -> int | None:
    parts = phrase.split()
    if not parts:
        return None
    length = len(parts)
    for start in range(0, len(words) - length + 1):
        if not _phrase_matches(phrase, words, start):
            continue
        if allow_negation and _negated(words, start, start + length):
            continue
        return start
    return None


def detect_tokens(text: str) -> set[str]:
    words = tokens(text)
    found: set[str] = set()
    for canonical, phrases in _SYNONYMS.items():
        if any(_find_phrase(phrase, words) is not None for phrase in phrases):
            found.add(canonical)
    return found


def detect_category(text: str) -> str | None:
    found = detect_tokens(text)
    best: tuple[int, str] | None = None
    for category, keys in _CATEGORY_TOKENS:
        hits = len(found & keys)
        if hits and (best is None or hits > best[0]):
            best = (hits, category)
    return best[1] if best else None


def suggest_detail(category: str | None, found: set[str]) -> str | None:
    if not category:
        return None
    if category == "pain":
        for detail, keys in _PAIN_DETAILS:
            if found & keys:
                return detail
        return "other"
    if category == "other":
        return "other"
    options = DETAILS.get(category, ())
    candidates: tuple[tuple[str, frozenset[str]], ...] = {
        "gi": (
            ("blood", frozenset({"bleeding"})),
            ("abdomen", frozenset({"abdomen"})),
            ("nausea", frozenset({"nausea"})),
            ("diarrhea", frozenset({"diarrhea"})),
            ("constipation", frozenset({"constipation"})),
            ("heartburn", frozenset({"heartburn"})),
        ),
        "skin": (
            ("rash", frozenset({"rash"})),
            ("itch", frozenset({"itch"})),
            ("redness", frozenset({"skin_red"})),
            ("swelling", frozenset({"swelling"})),
            ("wound", frozenset({"wound"})),
        ),
        "neuro": (
            ("seizure", frozenset({"seizure"})),
            ("speech", frozenset({"speech"})),
            ("numbness", frozenset({"numbness"})),
            ("dizziness", frozenset({"dizziness"})),
            ("headache", frozenset({"headache"})),
            ("tremor", frozenset({"tremor"})),
        ),
        "breathing": (
            ("dyspnea_rest", frozenset({"dyspnea"})),
            ("cough", frozenset({"cough"})),
        ),
        "ent": (
            ("throat", frozenset({"throat"})),
            ("nose", frozenset({"nose"})),
            ("ear", frozenset({"ear"})),
            ("voice", frozenset({"voice"})),
        ),
        "trauma": (
            ("head", frozenset({"headache"})),
            ("limb", frozenset({"limb"})),
            ("back", frozenset({"back"})),
        ),
        "fever": (),
    }.get(category, ())
    valid = {value for _, value in options}
    for value, keys in candidates:
        if found & keys and value in valid:
            return value
    return None


def detect_red_flags(text: str) -> list[str]:
    words = tokens(text)
    found: list[str] = []
    for key, phrases in _RED_FLAGS.items():
        for phrase in phrases:
            embedded_negation = any(part in _NEGATIONS for part in phrase.split())
            if _find_phrase(phrase, words, allow_negation=not embedded_negation) is not None:
                found.append(key)
                break
    return found


def parse_age(text: str) -> int | None:
    normalized = normalize(text)
    if any(stem in normalized for stem in ("ребен", "малыш", "груднич")) and "температур" in normalized:
        return None
    match = re.search(r"(\d{1,3})\s*(?:год|года|лет)", normalized)
    if match:
        value = int(match.group(1))
        return value if 0 < value < 120 else None
    match = re.search(r"мне\s+(\d{1,3})", normalized)
    if match:
        value = int(match.group(1))
        return value if 0 < value < 120 else None
    numbers = re.findall(r"\b(\d{1,3})\b", normalized)
    if len(numbers) == 1:
        value = int(numbers[0])
        return value if 0 < value < 120 else None
    for word in normalized.split():
        if word in _NUMBER_WORDS:
            value = _NUMBER_WORDS[word]
            return value if 0 < value < 120 else None
    if "год" in normalized and "пол" not in normalized:
        return 1
    return None


def parse_temperature(text: str) -> str | None:
    raw = (text or "").replace(",", ".")
    match = re.search(r"(\d{2}(?:\.\d)?)", raw)
    if match is None:
        return None
    value = float(match.group(1))
    if value < 38:
        return "low"
    if value < 39:
        return "mid"
    if value <= 39.5:
        return "high"
    return "critical"


def parse_duration(text: str) -> str | None:
    normalized = normalize(text)
    words = normalized.split()
    if not words:
        return None
    amount = _first_number(words)
    if "недел" in normalized or "месяц" in normalized:
        return ">week"
    if "час" in normalized:
        if any(stem in normalized for stem in ("пару", "пара ", "несколько")):
            return "hours"
        if amount is None or amount <= 1:
            return "<1h"
        return "hours"
    if "дн" in normalized or "сут" in normalized:
        if amount is None or amount <= 1:
            return "hours"
        if amount <= 3:
            return "1-3d"
        if amount <= 7:
            return "4-7d"
        return ">week"
    return None


def parse_severity(text: str) -> int | None:
    normalized = normalize(text)
    direct = re.search(r"\b(10|[1-9])\b", normalized)
    if direct:
        return int(direct.group(1))
    words = normalized.split()
    for word in words:
        if word in _NUMBER_WORDS and 1 <= _NUMBER_WORDS[word] <= 10:
            return _NUMBER_WORDS[word]
    if any(word.startswith(("невынос", "ужас", "сильн", "очень")) for word in words):
        return 9
    if any(word.startswith(("умерен", "терпим")) for word in words):
        return 5
    if any(word.startswith(("слаб", "немного", "легк")) for word in words):
        return 2
    return None


def _first_number(words: list[str]) -> int | None:
    for word in words:
        if word.isdigit():
            return int(word)
        if word in _NUMBER_WORDS:
            return _NUMBER_WORDS[word]
    return None


def parse_yes_no(text: str) -> str | None:
    normalized = normalize(text)
    if any(phrase in normalized for phrase in _UNKNOWN):
        return "unknown"
    if any(phrase in normalized for phrase in ("не было", "не бывает", "не наблюда", "не терял", "не было")):
        return "no"
    words = normalized.split()
    if words == ["не"]:
        return "no"
    if any(word in _NO for word in words):
        return "no"
    if any(word in _YES for word in words):
        return "yes"
    return None


def parse_sex(text: str) -> str | None:
    normalized = normalize(text)
    if normalized.startswith("ж") or "жен" in normalized:
        return "female"
    if normalized.startswith("м") or "муж" in normalized:
        return "male"
    return None


def match_option(text: str, options: tuple[tuple[str, str], ...]) -> str | None:
    normalized = normalize(text)
    if not normalized:
        return None
    for label, value in options:
        if normalize(label) == normalized:
            return value
    words = normalized.split()
    best: tuple[float, str] | None = None
    for label, value in options:
        score = 0.0
        for word in normalize(label).split():
            if len(word) < 3:
                continue
            if any(_same_word(word, candidate) for candidate in words):
                score += 1.0
        if score and (best is None or score > best[0]):
            best = (score, value)
    return best[1] if best else None


def detect_items(text: str, options: tuple[tuple[str, str], ...]) -> list[str]:
    normalized = normalize(text)
    aliases = {
        "диабет": "diabetes",
        "сахар": "diabetes",
        "гипертон": "hypertension",
        "давление": "hypertension",
        "астм": "asthma",
        "онколог": "oncology",
        "рак": "oncology",
        "опухол": "oncology",
        "сердц": "heart",
        "инфаркт": "heart",
        "инсульт": "heart",
        "гипертони": "hypertension",
    }
    found: list[str] = []
    words = normalized.split()
    for index, word in enumerate(words):
        if _negated(words, index, index + 1):
            continue
        for alias, value in aliases.items():
            if _same_word(word, alias) and value not in found:
                found.append(value)
    for label, value in options:
        if value == "none":
            continue
        for label_word in normalize(label).split():
            if len(label_word) <= 3:
                continue
            for index, word in enumerate(words):
                if (
                    _same_word(word, label_word)
                    and not _negated(words, index, index + 1)
                    and value not in found
                ):
                    found.append(value)
    if not found and ("нет" in words or "никаких" in normalized):
        found = ["none"]
    return found


def parse_meds(text: str) -> str | None:
    normalized = normalize(text)
    if any(stem in normalized for stem in ("варфарин", "ксарелто", "эликвис", "аспирин", "тромбо", "кроворазж", "антикоагул")):
        return "anticoagulant"
    words = normalized.split()
    if any(word in _NO for word in words):
        return "none"
    if any(word.startswith(("постоян", "каждый", "ежеднев", "регуляр")) for word in words):
        return "regular"
    if any(word.startswith(("иногда", "периодич", "по ситуации")) for word in words):
        return "sometimes"
    return None


def parse_allergy(text: str) -> str | None:
    normalized = normalize(text)
    words = normalized.split()
    if "нет аллерг" in normalized or "аллергии нет" in normalized or "не аллергик" in normalized:
        return "none"
    if "лекарств" in normalized or "препарат" in normalized or "таблет" in normalized:
        return "drug"
    if "пищ" in normalized or "продукт" in normalized or "еда" in normalized:
        return "food"
    if any(word in _NO for word in words) and not any(
        phrase in normalized for phrase in ("есть", "была", "бывает", "аллергия на")
    ):
        return "none"
    if "аллерг" in normalized:
        return "unknown"
    return None


def parse_pregnancy(text: str) -> str | None:
    normalized = normalize(text)
    if any(phrase in normalized for phrase in _UNKNOWN):
        return "unknown"
    if "не беремен" in normalized or "беременности нет" in normalized:
        return "no"
    if "беремен" in normalized:
        return "pregnant"
    if "не кормл" in normalized and "груд" not in normalized:
        return "no"
    if "кормл" in normalized or "груд" in normalized or "лактац" in normalized:
        return "lactating"
    words = normalized.split()
    if any(word in _NO for word in words):
        return "no"
    return None


def parse_habits(text: str) -> str | None:
    normalized = normalize(text)
    smoking = "кур" in normalized and "не кур" not in normalized
    alcohol = (
        any(stem in normalized for stem in ("алкогол", "пив", "вино", "водк"))
        and "не пью" not in normalized
        and "не употребля" not in normalized
    )
    if smoking and alcohol:
        return "both"
    if smoking:
        return "smoking"
    if alcohol:
        return "alcohol"
    if "пропуст" in normalized:
        return "skip"
    words = normalized.split()
    if any(word in _NO for word in words):
        return "none"
    return None


def parse_payment(text: str) -> str | None:
    normalized = normalize(text)
    if "омс" in normalized:
        return "oms"
    if "дмс" in normalized:
        return "dms"
    if "плат" in normalized:
        return "paid"
    if "не важ" in normalized or "любой" in normalized:
        return "any"
    return None


def parse_detail(category: str | None, text: str) -> str | None:
    if not category:
        return None
    if category == "fever":
        temperature = parse_temperature(text)
        if temperature:
            return temperature
    options = tuple(DETAILS.get(category, ()))
    direct = match_option(text, options)
    if direct:
        return direct
    found = detect_tokens(text)
    suggested = suggest_detail(category, found)
    if suggested:
        return suggested
    return None


def match_sex(text: str) -> str | None:
    return parse_sex(text)


def match_heredity(text: str) -> list[str]:
    return detect_items(text, HEREDITY)


def match_chronic(text: str) -> list[str]:
    return detect_items(text, CHRONIC)


def match_duration(text: str) -> str | None:
    normalized = normalize(text)
    if re.search(r"\d", normalized) or any(stem in normalized for stem in ("час", "дн", "недел", "месяц", "сут")):
        value = parse_duration(text)
        if value:
            return value
    return match_option(text, DURATIONS) or parse_duration(text)


def match_meds(text: str) -> str | None:
    return match_option(text, MEDS) or parse_meds(text)


def match_allergies(text: str) -> str | None:
    return match_option(text, ALLERGIES) or parse_allergy(text)


def match_pregnancy(text: str) -> str | None:
    return parse_pregnancy(text) or match_option(text, PREGNANCY)


def match_habits(text: str) -> str | None:
    return match_option(text, HABITS) or parse_habits(text)


def match_payment(text: str) -> str | None:
    return match_option(text, PAYMENT) or parse_payment(text)


def match_severity(text: str) -> int | None:
    return parse_severity(text)


def match_age(text: str) -> int | None:
    return parse_age(text)


def match_sex_option(text: str) -> str | None:
    return match_option(text, SEX) or parse_sex(text)
