from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from . import options
from .models import Answers


class Urgency(StrEnum):
    EMERGENCY = "emergency"
    URGENT_24H = "urgent_24h"
    PLANNED = "planned"
    SELF_CARE = "self_care"


class Place(StrEnum):
    AMBULANCE = "ambulance"
    EMERGENCY_ROOM = "emergency_room"
    CLINIC = "clinic"
    TELEMEDICINE = "telemedicine"
    PHARMACY = "pharmacy"


@dataclass(frozen=True, slots=True)
class RedSignal:
    key: str
    title: str
    explain: str


RED_SIGNALS: dict[str, RedSignal] = {
    "chest_pain": RedSignal("chest_pain", "боль в груди", "давящая боль в груди может быть признаком острого состояния сердца"),
    "dyspnea_rest": RedSignal("dyspnea_rest", "одышка в покое", "нехватка воздуха в покое быстро нарастает"),
    "syncope": RedSignal("syncope", "потеря сознания", "обморок может быть следствием опасного нарушения"),
    "seizure": RedSignal("seizure", "судороги", "судорожный приступ требует немедленной помощи"),
    "bleeding": RedSignal("bleeding", "кровотечение", "кровопотеря может стать угрожающей"),
    "stroke": RedSignal("stroke", "признаки инсульта", "при инсульте счёт идёт на минуты"),
    "anaphylaxis": RedSignal("anaphylaxis", "признаки анафилаксии", "отёк горла может перекрыть дыхание"),
    "severe_abdomen": RedSignal("severe_abdomen", "острая боль в животе", "такая боль может требовать экстренной операции"),
    "head_injury": RedSignal("head_injury", "травма головы с потерей сознания", "после травмы головы возможны скрытые повреждения"),
    "child_fever": RedSignal("child_fever", "высокая температура у ребёнка", "у детей высокая температура требует быстрой оценки"),
    "pregnancy_bleeding": RedSignal("pregnancy_bleeding", "кровотечение при беременности", "при беременности кровотечение опасно для матери и плода"),
}

_URGENCY_RANK: dict[Urgency, int] = {
    Urgency.SELF_CARE: 0,
    Urgency.PLANNED: 1,
    Urgency.URGENT_24H: 2,
    Urgency.EMERGENCY: 3,
}

_URGENT_PAIN_DETAILS: dict[str, str] = {
    "head": "невролог",
    "face": "стоматолог",
    "throat": "ЛОР",
    "ear": "ЛОР",
    "chest": "кардиолог",
    "back": "невролог",
    "limb": "травматолог-ортопед",
    "other": "терапевт",
}


@dataclass(frozen=True, slots=True)
class TriageResult:
    urgency: Urgency
    specialty: str
    place: Place
    reasons: tuple[str, ...]
    signals: tuple[RedSignal, ...] = ()

    @property
    def emergency(self) -> bool:
        return self.urgency is Urgency.EMERGENCY


def evaluate(answers: Answers) -> TriageResult:
    signals = _collect_signals(answers)
    if signals:
        reasons = tuple(signal.title for signal in signals)
        return TriageResult(Urgency.EMERGENCY, "врач скорой помощи", Place.AMBULANCE, reasons, tuple(signals))
    urgency, notes = _urgency(answers)
    specialty = _specialty(answers)
    place = _place(answers, urgency)
    return TriageResult(urgency, specialty, place, tuple(_dedupe(notes + _describe(answers))))


def _collect_signals(answers: Answers) -> list[RedSignal]:
    signals: list[RedSignal] = []
    for key in answers.red_flags:
        signal = RED_SIGNALS.get(key)
        if signal is not None and signal not in signals:
            signals.append(signal)
    if _is_child(answers) and answers.category == "fever" and answers.detail == "critical":
        signal = RED_SIGNALS["child_fever"]
        if signal not in signals:
            signals.append(signal)
    return signals


def _urgency(answers: Answers) -> tuple[Urgency, list[str]]:
    level = Urgency.SELF_CARE
    notes: list[str] = []

    def bump(target: Urgency, note: str) -> None:
        nonlocal level
        if _URGENCY_RANK[target] > _URGENCY_RANK[level]:
            level = target
        notes.append(note)

    age = answers.age
    severity = answers.severity or 0
    severe_category = answers.category in {"pain", "fever", "breathing", "gi", "neuro", "trauma"}

    if severity >= 9:
        bump(Urgency.URGENT_24H, "интенсивность 9–10 из 10")
    if answers.category == "pain" and answers.detail == "chest":
        bump(Urgency.URGENT_24H, "боль в груди требует очной оценки")
    if answers.category == "breathing" and answers.detail in {"dyspnea_rest", "dyspnea_load"}:
        bump(Urgency.URGENT_24H, "одышка")
    if answers.category == "neuro" and answers.detail in {"numbness", "speech", "seizure"}:
        bump(Urgency.URGENT_24H, "неврологические симптомы")
    if answers.category == "trauma" and answers.detail == "head":
        bump(Urgency.URGENT_24H, "травма головы")
    if answers.category == "gi" and answers.detail == "blood":
        bump(Urgency.URGENT_24H, "кровь в стуле или рвоте")
    if answers.category == "fever" and answers.detail == "high":
        bump(Urgency.URGENT_24H, "температура 39–39,5 °C")
    if answers.category == "fever" and answers.detail == "critical" and not _is_child(answers):
        bump(Urgency.URGENT_24H, "температура выше 39,5 °C")
    if age is not None and age < 1:
        bump(Urgency.URGENT_24H, "ребёнок до года")
    if age is not None and age >= 65 and severity >= 7:
        bump(Urgency.URGENT_24H, "возраст 65+ и выраженный симптом")
    if answers.pregnancy == "pregnant" and answers.category in {"pain", "gi", "fever"}:
        bump(Urgency.URGENT_24H, "беременность")
    if severity >= 7 and answers.duration in {"<1h", "hours", "1-3d"}:
        bump(Urgency.URGENT_24H, "сильный симптом в остром периоде")
    if answers.meds == "anticoagulant" and answers.category in {"trauma", "gi"}:
        bump(Urgency.URGENT_24H, "приём разжижающих кровь")
    if "oncology" in answers.chronic and answers.category == "fever":
        bump(Urgency.URGENT_24H, "температура при онкологическом заболевании")
    if "diabetes" in answers.chronic and answers.category == "skin" and answers.detail in {"wound", "swelling"}:
        bump(Urgency.URGENT_24H, "рана при диабете")
    if answers.red_unknown:
        titles = ", ".join(RED_SIGNALS[key].title for key in answers.red_unknown if key in RED_SIGNALS)
        if titles:
            bump(Urgency.URGENT_24H, f"не исключены тревожные признаки: {titles}")

    if severity >= 4:
        bump(Urgency.PLANNED, "умеренная интенсивность")
    if answers.category == "fever":
        bump(Urgency.PLANNED, "температура")
    if severe_category and answers.duration in {"<1h", "hours", "1-3d", "4-7d"}:
        bump(Urgency.PLANNED, "симптом появился недавно")
    if answers.pregnancy in {"pregnant", "lactating"}:
        bump(Urgency.PLANNED, "беременность или лактация")
    if _has_chronic(answers):
        bump(Urgency.PLANNED, "хронические заболевания")
    if age is not None and age >= 65:
        bump(Urgency.PLANNED, "возраст 65+")
    if answers.allergies in {"drug", "food"}:
        bump(Urgency.PLANNED, "аллергия в анамнезе")

    if level is Urgency.SELF_CARE:
        notes.append("признаков срочности не найдено")
    return level, notes


def _specialty(answers: Answers) -> str:
    if _is_child(answers):
        return {
            "trauma": "детский хирург",
            "ent": "ЛОР с детским приёмом",
            "skin": "детский дерматолог",
        }.get(answers.category or "", "педиатр")
    if answers.pregnancy == "pregnant" and (
        answers.category in {"gi", "fever"} or (answers.category == "pain" and answers.detail == "abdomen")
    ):
        return "акушер-гинеколог"
    category = answers.category
    detail = answers.detail or ""
    if category == "pain":
        if detail == "abdomen":
            return "хирург" if (answers.severity or 0) >= 8 else "гастроэнтеролог"
        return _URGENT_PAIN_DETAILS.get(detail, "терапевт")
    if category == "fever":
        return "терапевт"
    if category == "breathing":
        return "пульмонолог"
    if category == "gi":
        return "хирург" if detail == "blood" or (answers.severity or 0) >= 8 else "гастроэнтеролог"
    if category == "skin":
        return "дерматолог"
    if category == "neuro":
        return "невролог"
    if category == "trauma":
        return "травматолог-ортопед"
    if category == "ent":
        return "ЛОР"
    if "eye" in answers.tokens:
        return "офтальмолог"
    if "anxiety" in answers.tokens:
        return "психиатр или психотерапевт"
    if "tooth" in answers.tokens:
        return "стоматолог"
    return "терапевт"


def _place(answers: Answers, urgency: Urgency) -> Place:
    if urgency is Urgency.EMERGENCY:
        return Place.AMBULANCE
    if answers.category == "pain" and answers.detail == "chest":
        return Place.EMERGENCY_ROOM
    if answers.category == "breathing" and answers.detail == "dyspnea_rest":
        return Place.EMERGENCY_ROOM
    if urgency is Urgency.URGENT_24H:
        return Place.EMERGENCY_ROOM if (answers.severity or 0) >= 8 else Place.CLINIC
    if urgency is Urgency.PLANNED:
        return Place.CLINIC
    if answers.category == "skin" and answers.detail in {"itch", "rash"}:
        return Place.PHARMACY
    return Place.TELEMEDICINE


def _describe(answers: Answers) -> list[str]:
    notes: list[str] = []
    if answers.category:
        notes.append(f"основная жалоба: {options.CATEGORY_LABELS.get(answers.category, answers.category)}")
    if answers.detail_label:
        notes.append(f"уточнение: {answers.detail_label}")
    elif answers.detail:
        label = options.detail_label(answers.category, answers.detail)
        if label:
            notes.append(f"уточнение: {label}")
    if answers.age is not None:
        notes.append(f"возраст: {answers.age_label or options.age_label(answers.age)}")
    if answers.duration:
        notes.append(f"длительность: {options.DURATION_LABELS.get(answers.duration, answers.duration)}")
    if answers.severity is not None:
        notes.append(f"интенсивность: {options.severity_label(answers.severity)}")
    chronic = [options.CHRONIC_LABELS.get(item, item) for item in answers.chronic if item != "none"]
    if chronic:
        notes.append("хронические заболевания: " + ", ".join(chronic))
    if answers.allergies in {"drug", "food", "unknown"}:
        notes.append("аллергия: " + options.ALLERGY_LABELS.get(answers.allergies, answers.allergies))
    if answers.surgery:
        notes.append("операции или госпитализации за последний год")
    heredity = [options.HEREDITY_LABELS.get(item, item) for item in answers.heredity if item != "none"]
    if heredity:
        notes.append("наследственность: " + ", ".join(heredity))
    if answers.pregnancy:
        notes.append("беременность/лактация: " + options.PREGNANCY_LABELS.get(answers.pregnancy, answers.pregnancy))
    if answers.meds == "anticoagulant":
        notes.append("приём разжижающих кровь")
    return notes


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def _has_chronic(answers: Answers) -> bool:
    return bool(set(answers.chronic) - {"none"})


def _is_child(answers: Answers) -> bool:
    return answers.age is not None and answers.age < 18
