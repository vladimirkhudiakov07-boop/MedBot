from __future__ import annotations

import datetime as dt
from collections.abc import Sequence

from . import options
from .database import Stats
from .keyboards import callback_button, inline_keyboard
from .models import Answers, HistoryItem
from .triage import Place, TriageResult, Urgency

COMMANDS: tuple[dict[str, str], ...] = (
    {"name": "start", "description": "Начать опрос заново"},
    {"name": "help", "description": "Как работает бот и его ограничения"},
    {"name": "history", "description": "Мои прошлые обращения"},
    {"name": "restart", "description": "Сбросить ответы и начать сначала"},
    {"name": "forget", "description": "Удалить мою историю обращений"},
    {"name": "stats", "description": "Статистика обращений (для администратора)"},
    {"name": "stop", "description": "Остановить опрос"},
)

SHORT_URGENCY: dict[str, str] = {
    "emergency": "экстренно",
    "urgent_24h": "срочно, 24 часа",
    "planned": "планово",
    "self_care": "самопомощь",
}

SHORT_PLACE: dict[str, str] = {
    "ambulance": "скорая",
    "emergency_room": "приёмный покой",
    "clinic": "поликлиника",
    "telemedicine": "телемедицина",
    "pharmacy": "аптека",
}

URGENCY_TITLES: dict[Urgency, str] = {
    Urgency.EMERGENCY: "🔴 Экстренно",
    Urgency.URGENT_24H: "🟠 Срочно, в течение 24 часов",
    Urgency.PLANNED: "🟡 Планово",
    Urgency.SELF_CARE: "🟢 Самопомощь",
}

PLACE_TITLES: dict[Place, str] = {
    Place.AMBULANCE: "скорая помощь — 103 или 112",
    Place.EMERGENCY_ROOM: "приёмное отделение больницы",
    Place.CLINIC: "поликлиника по месту прикрепления",
    Place.TELEMEDICINE: "телемедицина",
    Place.PHARMACY: "аптека — консультация провизора",
}

_ACTIONS: dict[Urgency, str] = {
    Urgency.EMERGENCY: (
        "1. Позвоните 103 или 112 и оставайтесь на линии.\n"
        "2. Не ждите окончания опроса и не занимайтесь самолечением.\n"
        "3. Не садитесь за руль и попросите помощи у близких."
    ),
    Urgency.URGENT_24H: (
        "1. Обратитесь к врачу сегодня: приёмное отделение или поликлиника.\n"
        "2. Возьмите полис, паспорт и список принимаемых лекарств.\n"
        "3. Если станет хуже — звоните 103 или 112, не дожидаясь приёма."
    ),
    Urgency.PLANNED: (
        "1. Запишитесь к врачу в течение недели.\n"
        "2. Возьмите полис и паспорт, подготовьте список лекарств.\n"
        "3. Если появятся новые сильные симптомы — обратитесь раньше."
    ),
    Urgency.SELF_CARE: (
        "1. Понаблюдайте за симптомами 2–3 дня.\n"
        "2. Пейте достаточно воды, отдыхайте и не перегружайте организм.\n"
        "3. Если не станет лучше или появятся новые симптомы — обратитесь к врачу."
    ),
}


def start_text() -> str:
    return (
        "Здравствуйте! Я — МедБот, помощник по первичной маршрутизации.\n\n"
        "Я не ставлю диагноз и не заменяю врача.\n\n"
        "Сначала проверю опасные признаки — это 9 коротких вопросов. "
        "Если что-то из этого есть, сразу подскажу вызвать скорую. "
        "Потом уточню возраст, пол и детали жалобы.\n\n"
        "Отвечайте кнопками или обычным текстом. В любой момент можно вернуться назад.\n\n"
        "⚠️ Если состояние тяжёлое — не ждите конца опроса, звоните 103 или 112."
    )


def help_text() -> str:
    return (
        "**Как это работает**\n\n"
        "1. Сначала — 9 вопросов о критических признаках (боль в груди, дыхание, сознание, "
        "судороги, кровотечение, инсульт, анафилаксия, живот, травма головы).\n"
        "2. Затем возраст, пол и уточняющие вопросы о жалобе и анамнезе. "
        "Для детей и беременных добавляются отдельные проверки.\n"
        "3. Если критический признак подтверждён — опрос сразу прерывается и звучит инструкция 103/112.\n"
        "4. В конце — карточка: срочность, специальность врача, куда обратиться и почему.\n\n"
        "**Чего я не делаю**\n\n"
        "• не ставлю диагноз;\n"
        "• не назначаю лекарства и дозировки;\n"
        "• не заменяю экстренную помощь и очный приём.\n\n"
        "**Данные**\n\n"
        "Имя, телефон и текст сообщений не сохраняются. Завершённые обращения пишутся "
        "в локальную базу под псевдонимом (хеш пользователя) — их можно посмотреть командой "
        "/history и удалить командой /forget."
    )


def audio_hint() -> str:
    return (
        "Я пока не распознаю голосовые сообщения. "
        "Напишите, пожалуйста, текстом или выберите вариант кнопкой."
    )


def attachment_hint() -> str:
    return (
        "Я понимаю только текст и кнопки. "
        "Опишите, что беспокоит, сообщением или выберите вариант кнопкой."
    )


def stale_button_text() -> str:
    return "Кнопка устарела. Отправьте /start, чтобы начать опрос заново."


def unknown_hint() -> str:
    return "Не понял ответ. Выберите вариант кнопкой или напишите иначе."


def text_too_long(limit: int) -> str:
    return (
        f"Сообщение слишком длинное: больше {limit} символов. "
        "Опишите жалобу короче или выберите вариант кнопкой."
    )


def group_hint() -> str:
    return "Я работаю в личном чате: откройте диалог со мной и отправьте /start."


def farewell_text() -> str:
    return (
        "Остановил опрос. Текущая сессия удалена из памяти.\n\n"
        "Завершённые обращения остаются в истории — /history. "
        "Удалить их можно командой /forget.\n\n"
        "Когда понадобится — отправьте /start. При ухудшении состояния вызывайте скорую: 103 или 112."
    )


def card_hint() -> str:
    return "Опрос завершён. Нажмите «Пройти заново», чтобы начать новую консультацию."


def menu_text() -> str:
    return (
        "☰ **Меню**\n\n"
        "Продолжите опрос, начните заново или откройте справку и историю обращений."
    )


def history_text(items: Sequence[HistoryItem]) -> str:
    if not items:
        return (
            "📜 **Обращений пока нет**\n\n"
            "Завершите опрос — и результат появится здесь. История сохраняется между запусками бота."
        )
    lines = ["📜 **Ваши обращения**", ""]
    for item in items[:10]:
        moment = dt.datetime.fromtimestamp(item.at).strftime("%d.%m.%Y %H:%M")
        urgency = SHORT_URGENCY.get(item.urgency, item.urgency)
        place = SHORT_PLACE.get(item.place, item.place)
        lines.append(f"• {moment} — {urgency}, {item.specialty} ({place})")
    lines.append("")
    lines.append("Хранится локально: без имени и текста сообщений. Удалить — /forget.")
    return "\n".join(lines)


def stats_text(stats: Stats) -> str:
    lines = [
        "📊 **Статистика обращений**",
        "",
        f"Обработано запросов: **{stats.total_requests}**",
        f"Уникальных пользователей: **{stats.unique_users}**",
        f"Начали опрос: {stats.started}, завершили: {stats.completed}",
        "",
        "**По срочности**",
        f"• экстренно: {stats.emergency}",
        f"• срочно, 24 часа: {stats.urgent}",
        f"• планово: {stats.planned}",
        f"• самопомощь: {stats.self_care}",
    ]
    if stats.by_specialty:
        lines.extend(["", "**Топ специальностей**"])
        lines.extend(f"• {name}: {amount}" for name, amount in stats.by_specialty)
    if stats.by_day:
        lines.extend(["", "**За последние 7 дней**"])
        lines.extend(f"• {day}: {amount}" for day, amount in stats.by_day)
    lines.extend(["", "Данные агрегированы, без имён и текстов сообщений."])
    return "\n".join(lines)


def stats_denied_text(user_id: int | None = None) -> str:
    if user_id is None:
        return "Статистика доступна администратору бота."
    return (
        "Статистика доступна администратору бота.\n\n"
        f"Ваш ID: {user_id}. Чтобы открыть доступ, добавьте его в ADMIN_IDS в .env и перезапустите бота."
    )


def forget_text(removed: int) -> str:
    if removed:
        return (
            f"🗑 Удалено обращений: **{removed}**. "
            "Связанные события статистики тоже удалены."
        )
    return "В истории не было сохранённых обращений."


def script_text() -> str:
    return (
        "📞 **Что сказать диспетчеру**\n\n"
        "1. Адрес: улица, дом, квартира, подъезд, этаж.\n"
        "2. Что случилось: «человек без сознания», «сильная боль в груди», «трудно дышать».\n"
        "3. Когда началось и как менялось состояние.\n"
        "4. Возраст и пол.\n"
        "5. В сознании ли человек, дышит ли он.\n"
        "6. Какие лекарства принимает и на что аллергия.\n\n"
        "Не кладите трубку, пока диспетчер не разрешит. Если можете — откройте дверь и встретьте бригаду."
    )


def emergency_text(result: TriageResult) -> str:
    reasons = "\n".join(f"• {signal.title} — {signal.explain}" for signal in result.signals)
    return (
        "🚨 **Нужна экстренная помощь**\n\n"
        f"{reasons}\n\n"
        "Позвоните **103** или **112** прямо сейчас. Не ждите окончания опроса "
        "и не занимайтесь самолечением.\n\n"
        "Если рядом есть взрослый человек — попросите помочь. Не садитесь за руль.\n\n"
        "⚠️ Я не ставлю диагноз: перечисленные признаки требуют немедленного осмотра врача."
    )


def result_text(result: TriageResult, answers: Answers) -> str:
    reasons = "\n".join(f"• {reason}" for reason in result.reasons[:8])
    payment = options.PAYMENT_LABELS.get(answers.payment or "", "не указано")
    return (
        "📋 **Итог опроса**\n\n"
        f"**Срочность:** {URGENCY_TITLES[result.urgency]}\n"
        f"**Куда обратиться:** {PLACE_TITLES[result.place]}\n"
        f"**Врач:** {result.specialty}\n"
        f"**Оплата:** {payment} — {options.payment_hint(answers.payment)}\n\n"
        f"**Почему такой вывод:**\n{reasons}\n\n"
        f"**Что сделать сейчас:**\n{_ACTIONS[result.urgency]}\n\n"
        "⚠️ Это не диагноз. При ухудшении состояния — вызывайте скорую: 103 или 112."
    )


def start_keyboard() -> dict:
    return inline_keyboard(
        [
            [callback_button("Начать опрос", {"k": "nav", "v": "begin"})],
            [
                callback_button("Справка", {"k": "nav", "v": "help"}),
                callback_button("История", {"k": "nav", "v": "history"}),
            ],
        ]
    )


def help_keyboard() -> dict:
    return inline_keyboard(
        [
            [callback_button("Начать опрос", {"k": "nav", "v": "begin"})],
            [
                callback_button("▶ Продолжить", {"k": "nav", "v": "resume"}),
                callback_button("☰ Меню", {"k": "nav", "v": "menu"}),
            ],
        ]
    )


def resume_keyboard() -> dict:
    return inline_keyboard(
        [
            [callback_button("▶ Продолжить", {"k": "nav", "v": "resume"})],
            [callback_button("☰ Меню", {"k": "nav", "v": "menu"})],
        ]
    )


def menu_keyboard() -> dict:
    return inline_keyboard(
        [
            [
                callback_button("▶ Продолжить", {"k": "nav", "v": "resume"}),
                callback_button("🔄 Заново", {"k": "nav", "v": "restart"}),
            ],
            [
                callback_button("📖 Справка", {"k": "nav", "v": "help"}),
                callback_button("📜 История", {"k": "nav", "v": "history"}),
            ],
            [callback_button("📊 Статистика", {"k": "nav", "v": "stats"})],
        ]
    )


def result_keyboard() -> dict:
    return inline_keyboard(
        [
            [callback_button("Пройти заново", {"k": "nav", "v": "restart"})],
            [
                callback_button("История", {"k": "nav", "v": "history"}),
                callback_button("Справка", {"k": "nav", "v": "help"}),
            ],
        ]
    )


def emergency_keyboard() -> dict:
    return inline_keyboard(
        [
            [callback_button("Памятка 103/112", {"k": "nav", "v": "script"})],
            [callback_button("Начать заново", {"k": "nav", "v": "restart"})],
        ]
    )


def card_keyboard() -> dict:
    return inline_keyboard(
        [
            [callback_button("Пройти заново", {"k": "nav", "v": "restart"})],
            [callback_button("Справка", {"k": "nav", "v": "help"})],
        ]
    )
