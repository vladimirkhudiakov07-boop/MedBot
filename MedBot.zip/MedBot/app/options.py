from __future__ import annotations

from typing import Final

Option = tuple[str, str]

CATEGORIES: Final[tuple[Option, ...]] = (
    ("Боль", "pain"),
    ("Температура", "fever"),
    ("Дыхание", "breathing"),
    ("Живот и ЖКТ", "gi"),
    ("Кожа", "skin"),
    ("Неврология", "neuro"),
    ("Травма", "trauma"),
    ("ЛОР", "ent"),
    ("Другое", "other"),
)

DETAILS: Final[dict[str, tuple[Option, ...]]] = {
    "pain": (
        ("Голова", "head"),
        ("Лицо или зубы", "face"),
        ("Горло", "throat"),
        ("Ухо", "ear"),
        ("Грудь", "chest"),
        ("Живот", "abdomen"),
        ("Спина", "back"),
        ("Рука или нога", "limb"),
        ("Другое", "other"),
    ),
    "fever": (
        ("До 38 °C", "low"),
        ("38–39 °C", "mid"),
        ("39–39,5 °C", "high"),
        ("Выше 39,5 °C", "critical"),
    ),
    "breathing": (
        ("Одышка в покое", "dyspnea_rest"),
        ("Одышка при нагрузке", "dyspnea_load"),
        ("Кашель", "cough"),
        ("Боль при дыхании", "pain_breath"),
        ("Хрипы", "wheeze"),
    ),
    "gi": (
        ("Боль в животе", "abdomen"),
        ("Тошнота или рвота", "nausea"),
        ("Диарея", "diarrhea"),
        ("Запор", "constipation"),
        ("Кровь в стуле или рвоте", "blood"),
        ("Изжога", "heartburn"),
    ),
    "skin": (
        ("Сыпь", "rash"),
        ("Зуд", "itch"),
        ("Покраснение", "redness"),
        ("Отёк", "swelling"),
        ("Рана или гной", "wound"),
    ),
    "neuro": (
        ("Головная боль", "headache"),
        ("Головокружение", "dizziness"),
        ("Онемение или слабость", "numbness"),
        ("Нарушение речи или зрения", "speech"),
        ("Судороги", "seizure"),
        ("Тремор", "tremor"),
    ),
    "trauma": (
        ("Голова", "head"),
        ("Рука или нога", "limb"),
        ("Спина", "back"),
        ("Грудь или живот", "torso"),
        ("Другое", "other"),
    ),
    "ent": (
        ("Боль в горле", "throat"),
        ("Насморк", "nose"),
        ("Боль в ухе", "ear"),
        ("Проблемы с голосом", "voice"),
    ),
    "other": (),
}

AGES: Final[tuple[tuple[str, str, int], ...]] = (
    ("До 1 года", "infant", 0),
    ("1–6 лет", "child", 4),
    ("7–17 лет", "teen", 12),
    ("18–44", "adult", 30),
    ("45–64", "middle", 55),
    ("65+", "senior", 70),
)

DURATIONS: Final[tuple[Option, ...]] = (
    ("Менее часа", "<1h"),
    ("Несколько часов", "hours"),
    ("1–3 дня", "1-3d"),
    ("4–7 дней", "4-7d"),
    ("Больше недели", ">week"),
)

SEVERITIES: Final[tuple[tuple[str, int], ...]] = (
    ("1–3 — слабо", 2),
    ("4–6 — умеренно", 5),
    ("7–8 — сильно", 8),
    ("9–10 — невыносимо", 10),
)

CHRONIC: Final[tuple[Option, ...]] = (
    ("Диабет", "diabetes"),
    ("Гипертония", "hypertension"),
    ("Астма", "asthma"),
    ("Онкология", "oncology"),
    ("Болезни сердца", "heart"),
    ("Нет", "none"),
)

MEDS: Final[tuple[Option, ...]] = (
    ("Нет", "none"),
    ("Постоянно", "regular"),
    ("Иногда", "sometimes"),
    ("Разжижающие кровь", "anticoagulant"),
)

ALLERGIES: Final[tuple[Option, ...]] = (
    ("Нет", "none"),
    ("Лекарственная", "drug"),
    ("Пищевая", "food"),
    ("Есть, но не знаю какая", "unknown"),
)

SURGERY: Final[tuple[Option, ...]] = (
    ("Нет", "no"),
    ("Да", "yes"),
)

HEREDITY: Final[tuple[Option, ...]] = (
    ("Болезни сердца и сосудов", "heart"),
    ("Онкология", "oncology"),
    ("Диабет", "diabetes"),
    ("Нет", "none"),
)

PREGNANCY: Final[tuple[Option, ...]] = (
    ("Нет", "no"),
    ("Беременна", "pregnant"),
    ("Кормлю грудью", "lactating"),
    ("Затрудняюсь ответить", "unknown"),
)

HABITS: Final[tuple[Option, ...]] = (
    ("Нет", "none"),
    ("Курение", "smoking"),
    ("Алкоголь", "alcohol"),
    ("И то, и другое", "both"),
    ("Пропустить", "skip"),
)

PAYMENT: Final[tuple[Option, ...]] = (
    ("ОМС", "oms"),
    ("ДМС", "dms"),
    ("Платно", "paid"),
    ("Не важно", "any"),
)

SEX: Final[tuple[Option, ...]] = (
    ("Женский", "female"),
    ("Мужской", "male"),
)

CATEGORY_LABELS: Final[dict[str, str]] = {value: label for label, value in CATEGORIES}
DURATION_LABELS: Final[dict[str, str]] = {value: label for label, value in DURATIONS}
CHRONIC_LABELS: Final[dict[str, str]] = {value: label for label, value in CHRONIC}
HEREDITY_LABELS: Final[dict[str, str]] = {value: label for label, value in HEREDITY}
MEDS_LABELS: Final[dict[str, str]] = {value: label for label, value in MEDS}
ALLERGY_LABELS: Final[dict[str, str]] = {value: label for label, value in ALLERGIES}
PREGNANCY_LABELS: Final[dict[str, str]] = {value: label for label, value in PREGNANCY}
HABITS_LABELS: Final[dict[str, str]] = {value: label for label, value in HABITS}
PAYMENT_LABELS: Final[dict[str, str]] = {value: label for label, value in PAYMENT}
SURGERY_LABELS: Final[dict[str, str]] = {value: label for label, value in SURGERY}
SEX_LABELS: Final[dict[str, str]] = {value: label for label, value in SEX}

_AGE_LABELS: Final[dict[str, str]] = {value: label for label, value, _ in AGES}
_AGE_VALUES: Final[dict[str, int]] = {value: age for _, value, age in AGES}
SEVERITY_LABELS: Final[dict[int, str]] = {value: label for label, value in SEVERITIES}


def detail_label(category: str | None, value: str | None) -> str:
    if not category or not value:
        return ""
    for label, item in DETAILS.get(category, ()):
        if item == value:
            return label
    return ""


def severity_label(value: int | None) -> str:
    if value is None:
        return ""
    if value <= 3:
        return "1–3 из 10"
    if value <= 6:
        return "4–6 из 10"
    if value <= 8:
        return "7–8 из 10"
    return "9–10 из 10"


def age_label(value: int | None) -> str:
    if value is None:
        return ""
    if value <= 0:
        return "до 1 года"
    if value == 1:
        return "1 год"
    if value < 5:
        return f"{value} года"
    if value < 18:
        return f"{value} лет"
    if value % 10 == 1 and value % 100 != 11:
        return f"{value} год"
    if 1 < value % 10 < 5 and not 11 <= value % 100 <= 14:
        return f"{value} года"
    return f"{value} лет"


def age_from_bucket(value: str) -> int | None:
    return _AGE_VALUES.get(value)


def age_bucket_label(value: str) -> str:
    return _AGE_LABELS.get(value, "")


def payment_hint(value: str | None) -> str:
    return {
        "oms": "по полису ОМС помощь оказывается бесплатно в поликлинике по месту прикрепления",
        "dms": "по ДМС уточните в страховой список клиник и покрытие",
        "paid": "платно можно записаться в любую клинику без направления",
        "any": "подойдёт любой доступный вариант — начните с поликлиники",
    }.get(value or "", "уточните условия в выбранной клинике")
