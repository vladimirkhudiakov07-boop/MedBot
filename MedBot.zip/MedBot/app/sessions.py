from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass, field

from .models import Answers
from .triage import TriageResult

log = logging.getLogger(__name__)


@dataclass(slots=True)
class TrailPoint:
    state: str
    answers: Answers
    rf_index: int
    rf_answers: dict[str, str]


@dataclass(slots=True)
class Session:
    key: str
    chat_id: int | None = None
    user_id: int | None = None
    state: str = "start"
    answers: Answers = field(default_factory=Answers)
    rf_index: int = 0
    rf_answers: dict[str, str] = field(default_factory=dict)
    trail: list[TrailPoint] = field(default_factory=list)
    result: TriageResult | None = None
    completed: bool = False
    persisted: bool = False
    survey_started: bool = False
    started_at: float = 0.0
    welcome_at: float = 0.0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)

    def touch(self) -> None:
        self.updated_at = time.time()


class SessionStore:
    def __init__(
        self,
        ttl_seconds: int,
        history_limit: int = 5,
        max_sessions: int = 10000,
        max_age_seconds: int = 21600,
    ) -> None:
        self._ttl = ttl_seconds
        self._history_limit = history_limit
        self._max_sessions = max(1, max_sessions)
        self._max_age = max_age_seconds
        self._sessions: OrderedDict[str, Session] = OrderedDict()
        self._task: asyncio.Task[None] | None = None

    def get_or_create(self, key: str, chat_id: int | None, user_id: int | None) -> Session:
        session = self._sessions.get(key)
        if session is None:
            session = Session(key=key, chat_id=chat_id, user_id=user_id)
            self._sessions[key] = session
        else:
            session.chat_id = chat_id or session.chat_id
            session.user_id = user_id or session.user_id
            self._sessions.move_to_end(key)
        session.touch()
        self._evict_excess()
        return session

    def get(self, key: str) -> Session | None:
        session = self._sessions.get(key)
        if session is not None:
            self._sessions.move_to_end(key)
        return session

    def drop(self, key: str) -> None:
        self._sessions.pop(key, None)

    @property
    def size(self) -> int:
        return len(self._sessions)

    def cleanup(self) -> int:
        now = time.time()
        deadline = now - self._ttl
        hard_deadline = now - self._max_age
        stale = [
            key
            for key, session in self._sessions.items()
            if not session.lock.locked()
            and (session.updated_at < deadline or session.created_at < hard_deadline)
        ]
        for key in stale:
            self._sessions.pop(key, None)
        return len(stale)

    def _evict_excess(self) -> None:
        while len(self._sessions) > self._max_sessions:
            for key, session in self._sessions.items():
                if not session.lock.locked():
                    self._sessions.pop(key, None)
                    break
            else:
                break

    async def cleanup_forever(self, interval: int = 60) -> None:
        while True:
            await asyncio.sleep(interval)
            removed = self.cleanup()
            if removed:
                log.info("удалено устаревших сессий: %s", removed)

    def start_cleanup(self, interval: int = 60) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self.cleanup_forever(interval))

    async def close(self) -> None:
        if self._task is not None:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            self._task = None
        self._sessions.clear()
