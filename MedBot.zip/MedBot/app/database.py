from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from .models import Answers, HistoryItem
from .triage import TriageResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_hash TEXT NOT NULL,
    created_at REAL NOT NULL,
    urgency TEXT NOT NULL,
    specialty TEXT NOT NULL,
    place TEXT NOT NULL,
    category TEXT,
    detail TEXT,
    age INTEGER,
    sex TEXT,
    payment TEXT,
    red_flags TEXT NOT NULL DEFAULT '[]',
    duration_seconds INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_requests_user ON requests(user_hash, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_requests_created ON requests(created_at);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_hash TEXT NOT NULL,
    event TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at);
"""


@dataclass(frozen=True, slots=True)
class Stats:
    total_requests: int
    unique_users: int
    emergency: int
    urgent: int
    planned: int
    self_care: int
    started: int
    completed: int
    by_specialty: tuple[tuple[str, int], ...]
    by_day: tuple[tuple[str, int], ...]


class Database:
    def __init__(self, path: str | Path, salt: str = "") -> None:
        self._path = Path(path)
        self._salt = salt.strip()
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        async with self._lock:
            await asyncio.to_thread(self._open)

    async def close(self) -> None:
        async with self._lock:
            if self._conn is not None:
                await asyncio.to_thread(self._conn.close)
                self._conn = None

    def user_hash(self, user_key: str) -> str:
        payload = f"{self._load_salt()}:{user_key}".encode()
        return hashlib.sha256(payload).hexdigest()[:32]

    async def log_event(self, user_key: str, event: str) -> None:
        await self._write(
            "INSERT INTO events (user_hash, event, created_at) VALUES (?, ?, ?)",
            (self.user_hash(user_key), event, time.time()),
        )

    async def save_request(
        self,
        user_key: str,
        answers: Answers,
        result: TriageResult,
        started_at: float,
    ) -> None:
        duration = max(0, int(time.time() - started_at)) if started_at else 0
        await self._write(
            "INSERT INTO requests "
            "(user_hash, created_at, urgency, specialty, place, category, detail, age, sex, payment, red_flags, duration_seconds) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                self.user_hash(user_key),
                time.time(),
                result.urgency.value,
                result.specialty,
                result.place.value,
                answers.category,
                answers.detail,
                answers.age,
                answers.sex,
                answers.payment,
                json.dumps(answers.red_flags, ensure_ascii=False),
                duration,
            ),
        )
        await self.log_event(user_key, "request_completed")

    async def history(self, user_key: str, limit: int = 10) -> list[HistoryItem]:
        rows = await self._read(
            "SELECT created_at, urgency, specialty, place FROM requests "
            "WHERE user_hash = ? ORDER BY id DESC LIMIT ?",
            (self.user_hash(user_key), max(1, limit)),
        )
        return [
            HistoryItem(
                at=float(row["created_at"]),
                urgency=str(row["urgency"]),
                specialty=str(row["specialty"]),
                place=str(row["place"]),
            )
            for row in rows
        ]

    async def stats(self) -> Stats:
        totals = await self._one(
            "SELECT COUNT(*) AS total, "
            "COUNT(DISTINCT user_hash) AS users, "
            "COALESCE(SUM(CASE WHEN urgency = 'emergency' THEN 1 ELSE 0 END), 0) AS emergency, "
            "COALESCE(SUM(CASE WHEN urgency = 'urgent_24h' THEN 1 ELSE 0 END), 0) AS urgent, "
            "COALESCE(SUM(CASE WHEN urgency = 'planned' THEN 1 ELSE 0 END), 0) AS planned, "
            "COALESCE(SUM(CASE WHEN urgency = 'self_care' THEN 1 ELSE 0 END), 0) AS self_care "
            "FROM requests"
        )
        events = await self._one(
            "SELECT "
            "COALESCE(SUM(CASE WHEN event = 'survey_started' THEN 1 ELSE 0 END), 0) AS started, "
            "COALESCE(SUM(CASE WHEN event = 'request_completed' THEN 1 ELSE 0 END), 0) AS completed "
            "FROM events"
        )
        specialties = await self._read(
            "SELECT specialty, COUNT(*) AS amount FROM requests "
            "GROUP BY specialty ORDER BY amount DESC LIMIT 5"
        )
        days = await self._read(
            "SELECT strftime('%d.%m', created_at, 'unixepoch', 'localtime') AS day, COUNT(*) AS amount "
            "FROM requests WHERE created_at >= ? "
            "GROUP BY day ORDER BY day",
            (time.time() - 7 * 86400,),
        )
        return Stats(
            total_requests=int(totals["total"] or 0),
            unique_users=int(totals["users"] or 0),
            emergency=int(totals["emergency"] or 0),
            urgent=int(totals["urgent"] or 0),
            planned=int(totals["planned"] or 0),
            self_care=int(totals["self_care"] or 0),
            started=int(events["started"] or 0),
            completed=int(events["completed"] or 0),
            by_specialty=tuple((str(row["specialty"]), int(row["amount"])) for row in specialties),
            by_day=tuple((str(row["day"]), int(row["amount"])) for row in days),
        )

    async def delete_history(self, user_key: str) -> int:
        return await self._delete_user(self.user_hash(user_key))

    async def _delete_user(self, user_hash: str) -> int:
        async with self._lock:
            return await asyncio.to_thread(self._delete_user_sync, user_hash)

    def _delete_user_sync(self, user_hash: str) -> int:
        conn = self._require()
        count = int(conn.execute("SELECT COUNT(*) FROM requests WHERE user_hash = ?", (user_hash,)).fetchone()[0])
        conn.execute("DELETE FROM requests WHERE user_hash = ?", (user_hash,))
        conn.execute("DELETE FROM events WHERE user_hash = ?", (user_hash,))
        conn.commit()
        return count

    async def _write(self, sql: str, params: tuple[object, ...]) -> None:
        async with self._lock:
            await asyncio.to_thread(self._execute, sql, params)

    async def _read(self, sql: str, params: tuple[object, ...] = ()) -> list[sqlite3.Row]:
        async with self._lock:
            return await asyncio.to_thread(self._fetch_all, sql, params)

    async def _one(self, sql: str, params: tuple[object, ...] = ()) -> sqlite3.Row:
        rows = await self._read(sql, params)
        return rows[0]

    def _open(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._load_salt()
        conn = sqlite3.connect(self._path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(SCHEMA)
        conn.commit()
        self._conn = conn

    def _load_salt(self) -> str:
        if self._salt:
            return self._salt
        salt_file = self._path.parent / ".history_salt"
        if salt_file.is_file():
            self._salt = salt_file.read_text(encoding="utf-8").strip()
        if not self._salt:
            self._salt = secrets.token_hex(16)
            salt_file.write_text(self._salt, encoding="utf-8")
        return self._salt

    def _execute(self, sql: str, params: tuple[object, ...]) -> None:
        conn = self._require()
        conn.execute(sql, params)
        conn.commit()

    def _fetch_all(self, sql: str, params: tuple[object, ...]) -> list[sqlite3.Row]:
        conn = self._require()
        return list(conn.execute(sql, params).fetchall())

    def _require(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("База данных не подключена")
        return self._conn
