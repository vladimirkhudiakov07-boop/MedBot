from __future__ import annotations

import time
from collections.abc import Sequence
from dataclasses import dataclass

from . import keyboards, nlu, options, red_flags, texts, triage
from .keyboards import callback_button, inline_keyboard
from .models import Answers, Outgoing
from .sessions import Session, TrailPoint

BASE_STEPS: tuple[str, ...] = (
    "red_flags",
    "age",
    "sex",
    "vital_flags",
    "complaint",
    "detail",
    "duration",
    "severity",
    "chronic",
    "meds",
    "allergies",
    "surgery",
    "heredity",
    "pregnancy",
    "habits",
    "payment",
)

_DETAIL_TITLES: dict[str, str] = {
    "pain": "Где болит?",
    "fever": "Какая температура?",
    "breathing": "Что именно с дыханием?",
    "gi": "Что именно беспокоит?",
    "skin": "Что именно на коже?",
    "neuro": "Что именно беспокоит?",
    "trauma": "Что повреждено?",
    "ent": "Что именно беспокоит?",
}

_VALUE_LABELS: dict[str, dict[str, str]] = {
    "sex": options.SEX_LABELS,
    "complaint": options.CATEGORY_LABELS,
    "duration": options.DURATION_LABELS,
    "meds": options.MEDS_LABELS,
    "allergies": options.ALLERGY_LABELS,
    "pregnancy": options.PREGNANCY_LABELS,
    "habits": options.HABITS_LABELS,
    "payment": options.PAYMENT_LABELS,
    "surgery": options.SURGERY_LABELS,
}


@dataclass(frozen=True, slots=True)
class CallbackOutcome:
    ack_text: str | None = None
    ack_keyboard: dict | None = None
    messages: tuple[Outgoing, ...] = ()


class Dialog:
    def welcome(self, session: Session) -> tuple[Outgoing, ...]:
        self.reset(session)
        session.welcome_at = time.time()
        return (Outgoing(texts.start_text(), texts.start_keyboard()),)

    def reset(self, session: Session) -> None:
        session.state = "start"
        session.answers = Answers()
        session.rf_index = 0
        session.rf_answers.clear()
        session.trail.clear()
        session.result = None
        session.completed = False
        session.persisted = False
        session.survey_started = False
        session.started_at = 0.0
        session.touch()

    def help(self) -> tuple[Outgoing, ...]:
        return (Outgoing(texts.help_text(), texts.help_keyboard()),)

    def script(self) -> tuple[Outgoing, ...]:
        return (Outgoing(texts.script_text(), texts.emergency_keyboard()),)

    def current(self, session: Session) -> tuple[Outgoing, ...]:
        return self._render(session)

    def handle_text(self, session: Session, text: str) -> tuple[Outgoing, ...]:
        raw = (text or "").strip()
        if not raw:
            return self._render(session)
        flags = nlu.detect_red_flags(raw)
        if flags:
            return self._emergency(session, flags)
        if session.state in {"result", "emergency"}:
            return self._after_card(session, raw)
        if session.state in {"red_flags", "vital_flags"}:
            return self._text_flags(session, raw)
        handler = getattr(self, f"_text_{session.state}", None)
        if handler is None:
            return self._render(session)
        return handler(session, raw)

    def handle_callback(self, session: Session, payload: dict) -> CallbackOutcome:
        kind = str(payload.get("k") or "")
        field = str(payload.get("f") or "")
        value = str(payload.get("v") or "")
        if kind == "nav":
            return self._navigate(session, value)
        if session.state in {"result", "emergency"}:
            return CallbackOutcome(ack_text="Опрос завершён. Нажмите «Пройти заново».", messages=())
        if kind == "pick":
            if field != session.state:
                return CallbackOutcome(ack_text="Этот вопрос уже пройден.")
            label = self._label(session, field, value)
            self._apply_pick(session, field, value)
            return CallbackOutcome(ack_text=f"✅ {label}", messages=self._advance(session))
        if kind in {"toggle", "done"}:
            return self._multiselect_action(session, kind, field, value)
        if kind == "rf":
            return self._red_flag_action(session, value)
        return CallbackOutcome()

    def _multiselect_action(self, session: Session, kind: str, field: str, value: str) -> CallbackOutcome:
        if field not in {"chronic", "heredity"} or session.state != field:
            return CallbackOutcome(ack_text="Этот вопрос уже пройден.")
        values: list[str] = getattr(session.answers, field)
        if kind == "toggle":
            if value == "none":
                values.clear()
                values.append("none")
            else:
                if "none" in values:
                    values.remove("none")
                if value in values:
                    values.remove(value)
                else:
                    values.append(value)
            text, keyboard = self._multiselect_view(session, field)
            session.touch()
            return CallbackOutcome(ack_text=text, ack_keyboard=keyboard)
        if not values:
            values.append("none")
        label = self._items_label(field, values)
        return CallbackOutcome(ack_text=f"✅ {label}", messages=self._advance(session))

    def _red_flag_action(self, session: Session, value: str) -> CallbackOutcome:
        if session.state not in {"red_flags", "vital_flags"}:
            return CallbackOutcome(ack_text="Этот вопрос уже пройден.")
        questions = self._questions_for(session, session.state)
        if session.rf_index >= len(questions):
            return CallbackOutcome(ack_text="Этот вопрос уже пройден.")
        question = questions[session.rf_index]
        if value == "yes":
            return CallbackOutcome(ack_text="✅ Да", messages=self._flag(session, question.key))
        if value not in {"no", "unknown"}:
            return CallbackOutcome(ack_text="Не понял ответ.")
        self._remember_unknown(session, question.key, value)
        session.rf_answers[question.key] = value
        session.rf_index += 1
        session.touch()
        return CallbackOutcome(ack_text="✅ Нет" if value == "no" else "✅ Не знаю", messages=self._render(session))

    def _navigate(self, session: Session, action: str) -> CallbackOutcome:
        if action == "begin":
            if session.state == "start" or session.completed:
                if session.completed:
                    self.reset(session)
                self._enter(session, "red_flags")
            return CallbackOutcome(ack_text="Начинаем", messages=self._render(session))
        if action == "restart":
            messages = self.welcome(session)
            return CallbackOutcome(ack_text="🔄 Начинаем заново", messages=messages)
        if action == "back":
            if session.completed:
                return CallbackOutcome(ack_text=texts.stale_button_text())
            return CallbackOutcome(ack_text="↩ Назад", messages=self._back(session))
        if action == "help":
            return CallbackOutcome(ack_text="📖 Как это работает", messages=self.help())
        if action == "menu":
            return CallbackOutcome(
                ack_text="☰ Меню",
                messages=(Outgoing(texts.menu_text(), texts.menu_keyboard()),),
            )
        if action == "resume":
            return CallbackOutcome(ack_text="▶ Продолжаем", messages=self._render(session))
        if action == "history":
            return CallbackOutcome(ack_text="История доступна по команде /history.")
        if action == "script":
            return CallbackOutcome(ack_text="📞 Памятка", messages=self.script())
        return CallbackOutcome(ack_text="Не понял действие.")

    def _active_steps(self, session: Session) -> list[str]:
        steps = list(BASE_STEPS)
        if not red_flags.age_specific_questions(session.answers):
            steps.remove("vital_flags")
        if not _may_be_pregnant(session.answers):
            steps.remove("pregnancy")
        return steps

    def _questions_for(self, session: Session, state: str) -> list[red_flags.RedFlagQuestion]:
        if state == "red_flags":
            return list(red_flags.UNIVERSAL_QUESTIONS)
        if state == "vital_flags":
            return red_flags.age_specific_questions(session.answers)
        return []

    def _progress(self, session: Session, state: str) -> str:
        steps = self._active_steps(session)
        if state not in steps:
            return ""
        index = steps.index(state) + 1
        total = len(steps)
        percent = round(index * 100 / total)
        filled = round(percent / 10)
        bar = "▰" * filled + "▱" * (10 - filled)
        return f"Шаг {index} из {total} · {bar} {percent}%"

    def _enter(self, session: Session, state: str) -> None:
        if state == session.state:
            session.touch()
            return
        session.trail.append(
            TrailPoint(session.state, session.answers.clone(), session.rf_index, dict(session.rf_answers))
        )
        session.state = state
        session.rf_index = 0
        session.rf_answers.clear()
        session.touch()
        if state in {"result", "emergency"}:
            session.completed = True
            session.result = triage.evaluate(session.answers)

    def _advance(self, session: Session) -> tuple[Outgoing, ...]:
        steps = self._active_steps(session)
        start = BASE_STEPS.index(session.state) + 1 if session.state in BASE_STEPS else 0
        target = "result"
        for name in BASE_STEPS[start:]:
            if name in steps:
                target = name
                break
        self._enter(session, target)
        return self._render(session)

    def _back(self, session: Session) -> tuple[Outgoing, ...]:
        if session.state in {"red_flags", "vital_flags"} and session.rf_index > 0:
            questions = self._questions_for(session, session.state)
            session.rf_index -= 1
            if session.rf_index < len(questions):
                session.rf_answers.pop(questions[session.rf_index].key, None)
            session.touch()
            return self._render(session)
        if session.trail:
            point = session.trail.pop()
            session.state = point.state
            session.answers = point.answers
            session.rf_index = point.rf_index
            session.rf_answers = dict(point.rf_answers)
            if session.state in {"red_flags", "vital_flags"}:
                questions = self._questions_for(session, session.state)
                if session.rf_index >= len(questions):
                    session.rf_index = max(0, len(questions) - 1)
                    if questions:
                        session.rf_answers.pop(questions[session.rf_index].key, None)
            session.result = None
            session.completed = False
            session.touch()
            return self._render(session)
        self.reset(session)
        return self._render(session)

    def _emergency(self, session: Session, keys: Sequence[str]) -> tuple[Outgoing, ...]:
        for key in keys:
            if key in triage.RED_SIGNALS and key not in session.answers.red_flags:
                session.answers.red_flags.append(key)
        if not session.answers.red_flags:
            return self._render(session)
        if session.state == "emergency":
            session.result = triage.evaluate(session.answers)
            session.touch()
            return self._render(session)
        session.result = None
        self._enter(session, "emergency")
        return self._render(session)

    def _flag(self, session: Session, key: str) -> tuple[Outgoing, ...]:
        return self._emergency(session, [key])

    def _remember_unknown(self, session: Session, key: str, value: str) -> None:
        unknown = session.answers.red_unknown
        if value == "unknown":
            if key not in unknown:
                unknown.append(key)
        elif key in unknown:
            unknown.remove(key)

    def _render(self, session: Session) -> tuple[Outgoing, ...]:
        state = session.state
        if state == "start":
            return (Outgoing(texts.start_text(), texts.start_keyboard()),)
        if state == "emergency":
            result = session.result or triage.evaluate(session.answers)
            return (Outgoing(texts.emergency_text(result), texts.emergency_keyboard()),)
        if state == "result":
            result = session.result or triage.evaluate(session.answers)
            return (Outgoing(texts.result_text(result, session.answers), texts.result_keyboard()),)
        if state in {"red_flags", "vital_flags"}:
            questions = self._questions_for(session, state)
            if session.rf_index >= len(questions):
                return self._advance(session)
        return (self._question(session),)

    def _question(self, session: Session) -> Outgoing:
        state = session.state
        header = self._progress(session, state)
        prefix = f"{header}\n\n" if header else ""
        answers = session.answers
        if state == "age":
            return Outgoing(
                prefix + "Сколько вам лет?\n\nВозраст помогает выбрать врача и учесть детские или возрастные риски.",
                self._options_keyboard("age", [(label, value) for label, value, _ in options.AGES], 2),
            )
        if state == "sex":
            return Outgoing(
                prefix + "Укажите пол.\n\nЭто нужно для вопросов о беременности и некоторых рисках.",
                self._options_keyboard("sex", options.SEX, 2),
            )
        if state == "complaint":
            selected = {answers.category} if answers.category else set()
            return Outgoing(
                prefix + "Что беспокоит больше всего?\n\nВыберите основную жалобу — о ней и будем говорить.",
                self._options_keyboard("complaint", options.CATEGORIES, 2, selected=selected),
            )
        if state == "detail":
            category = answers.category or "other"
            title = _DETAIL_TITLES.get(category, "Расскажите подробнее.")
            items = options.DETAILS.get(category, ())
            if not items:
                return Outgoing(
                    prefix + title + "\n\nОпишите обычным текстом, например: «ломит поясницу третий день».",
                    self._back_keyboard(),
                )
            return Outgoing(prefix + title, self._options_keyboard("detail", items, 2))
        if state == "duration":
            return Outgoing(
                prefix + "Как давно это началось?",
                self._options_keyboard("duration", options.DURATIONS, 1),
            )
        if state == "severity":
            return Outgoing(
                prefix + "Насколько сильно это ощущается? Оцените от 1 до 10.",
                self._options_keyboard(
                    "severity",
                    [(label, str(value)) for label, value in options.SEVERITIES],
                    1,
                ),
            )
        if state in {"red_flags", "vital_flags"}:
            return self._red_flag_question(session, prefix, state)
        if state in {"chronic", "heredity"}:
            text, keyboard = self._multiselect_view(session, state)
            return Outgoing(text, keyboard)
        if state == "meds":
            return Outgoing(
                prefix + "Принимаете ли вы лекарства?",
                self._options_keyboard("meds", options.MEDS, 1),
            )
        if state == "allergies":
            return Outgoing(
                prefix + "Есть ли аллергия на лекарства или продукты?",
                self._options_keyboard("allergies", options.ALLERGIES, 1),
            )
        if state == "surgery":
            return Outgoing(
                prefix + "Были ли операции или госпитализации за последние 12 месяцев?",
                self._options_keyboard("surgery", options.SURGERY, 2),
            )
        if state == "pregnancy":
            return Outgoing(
                prefix + "Беременность или грудное вскармливание?",
                self._options_keyboard("pregnancy", options.PREGNANCY, 1),
            )
        if state == "habits":
            return Outgoing(
                prefix + "Курите или употребляете алкоголь?\n\nВопрос необязательный — можно пропустить.",
                self._options_keyboard("habits", options.HABITS, 1),
            )
        if state == "payment":
            return Outgoing(
                prefix + "Как планируете получать помощь?",
                self._options_keyboard("payment", options.PAYMENT, 2),
            )
        return Outgoing(texts.start_text(), texts.start_keyboard())

    def _red_flag_question(self, session: Session, prefix: str, state: str) -> Outgoing:
        questions = self._questions_for(session, state)
        question = questions[min(session.rf_index, len(questions) - 1)]
        counter = f"Признак {session.rf_index + 1} из {len(questions)}"
        text = f"{prefix}{counter}\n\n{question.question}\n\n{question.hint}"
        keyboard = inline_keyboard(
            [
                [
                    callback_button("Да", {"k": "rf", "v": "yes"}),
                    callback_button("Нет", {"k": "rf", "v": "no"}),
                    callback_button("Не знаю", {"k": "rf", "v": "unknown"}),
                ],
                [
                    callback_button("◀ Назад", {"k": "nav", "v": "back"}),
                    callback_button("☰ Меню", {"k": "nav", "v": "menu"}),
                ],
            ]
        )
        return Outgoing(text, keyboard)

    def _multiselect_view(self, session: Session, field: str) -> tuple[str, dict]:
        if field == "chronic":
            items = options.CHRONIC
            labels = options.CHRONIC_LABELS
            title = "Есть ли хронические заболевания?"
        else:
            items = options.HEREDITY
            labels = options.HEREDITY_LABELS
            title = "У близких родственников были эти заболевания?"
        selected = list(getattr(session.answers, field))
        chosen = ", ".join(
            "✓ " + labels[value] for value in selected if value in labels and value != "none"
        )
        chosen = chosen or "ничего не отмечено"
        header = self._progress(session, field)
        prefix = f"{header}\n\n" if header else ""
        text = f"{prefix}{title}\n\nМожно выбрать несколько. Отмечено: {chosen}."
        rows: list[list[dict]] = []
        for row in keyboards.chunk(list(items), 1):
            rows.append(
                [
                    callback_button(
                        ("✓ " if value in selected else "") + label,
                        {"k": "toggle", "f": field, "v": value},
                    )
                    for label, value in row
                ]
            )
        rows.append([callback_button("Готово", {"k": "done", "f": field})])
        rows.append(
            [
                callback_button("◀ Назад", {"k": "nav", "v": "back"}),
                callback_button("☰ Меню", {"k": "nav", "v": "menu"}),
            ]
        )
        return text, inline_keyboard(rows)

    def _options_keyboard(
        self,
        field: str,
        items: Sequence[tuple[str, str]],
        per_row: int,
        selected: set[str] | None = None,
    ) -> dict:
        marked = selected or set()
        rows: list[list[dict]] = []
        for row in keyboards.chunk(list(items), per_row):
            rows.append(
                [
                    callback_button(
                        ("✓ " if value in marked else "") + label,
                        {"k": "pick", "f": field, "v": value},
                    )
                    for label, value in row
                ]
            )
        rows.append(
            [
                callback_button("◀ Назад", {"k": "nav", "v": "back"}),
                callback_button("☰ Меню", {"k": "nav", "v": "menu"}),
            ]
        )
        return inline_keyboard(rows)

    def _back_keyboard(self) -> dict:
        return inline_keyboard(
            [
                [
                    callback_button("◀ Назад", {"k": "nav", "v": "back"}),
                    callback_button("☰ Меню", {"k": "nav", "v": "menu"}),
                ]
            ]
        )

    def _apply_pick(self, session: Session, field: str, value: str) -> None:
        answers = session.answers
        if field == "age":
            age = options.age_from_bucket(value)
            if age is not None:
                answers.age = age
                answers.age_label = options.age_bucket_label(value)
        elif field == "sex":
            answers.sex = value
        elif field == "complaint":
            answers.category = value
            answers.detail = None
            answers.detail_label = ""
        elif field == "detail":
            answers.detail = value
            answers.detail_label = options.detail_label(answers.category, value)
        elif field == "duration":
            answers.duration = value
        elif field == "severity":
            answers.severity = int(value)
        elif field == "meds":
            answers.meds = value
        elif field == "allergies":
            answers.allergies = value
        elif field == "surgery":
            answers.surgery = value == "yes"
        elif field == "pregnancy":
            answers.pregnancy = value
        elif field == "habits":
            answers.habits = value
        elif field == "payment":
            answers.payment = value
        if not _needs_pregnancy(answers):
            answers.pregnancy = None
        session.touch()

    def _label(self, session: Session, field: str, value: str) -> str:
        if field == "age":
            return options.age_bucket_label(value) or value
        if field == "detail":
            label = options.detail_label(session.answers.category, value)
            return label or value
        if field == "severity":
            try:
                return options.severity_label(int(value))
            except ValueError:
                return value
        labels = _VALUE_LABELS.get(field)
        if labels:
            return labels.get(value, value)
        return value

    def _items_label(self, field: str, values: Sequence[str]) -> str:
        labels = options.CHRONIC_LABELS if field == "chronic" else options.HEREDITY_LABELS
        names = [labels[value] for value in values if value in labels and value != "none"]
        return ", ".join(names) if names else "Нет"

    def _reprompt(self, session: Session) -> tuple[Outgoing, ...]:
        current = self._question(session)
        return (Outgoing(f"{texts.unknown_hint()}\n\n{current.text}", current.keyboard),)

    def _after_card(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        lower = raw.lower()
        if any(word in lower for word in ("заново", "сначала", "начать", "новый", "запусти")):
            return self.welcome(session)
        if any(word in lower for word in ("помощ", "помоги", "справк", "help", "как это работает", "как работает")):
            return self.help()
        return (Outgoing(texts.card_hint(), texts.card_keyboard()),)

    def _text_start(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        lower = raw.lower()
        if any(word in lower for word in ("начать", "старт", "давай", "поехали")):
            self._enter(session, "red_flags")
            return self._render(session)
        found = nlu.detect_tokens(raw)
        category = nlu.detect_category(raw)
        if not found and not category:
            return (Outgoing(texts.start_text(), texts.start_keyboard()),)
        session.answers.tokens |= found
        if category:
            session.answers.category = category
            detail = nlu.suggest_detail(category, found)
            if detail:
                session.answers.detail = detail
                session.answers.detail_label = options.detail_label(category, detail)
        self._enter(session, "red_flags")
        return self._render(session)

    def _text_age(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        age = nlu.match_age(raw)
        if age is None:
            return self._reprompt(session)
        session.answers.age = age
        session.answers.age_label = options.age_label(age)
        return self._advance(session)

    def _text_sex(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_sex_option(raw)
        if value is None:
            return self._reprompt(session)
        self._apply_pick(session, "sex", value)
        return self._advance(session)

    def _text_complaint(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        category = nlu.detect_category(raw) or nlu.match_option(raw, options.CATEGORIES)
        if category is None:
            return self._reprompt(session)
        session.answers.tokens |= nlu.detect_tokens(raw)
        self._apply_pick(session, "complaint", category)
        detail = nlu.suggest_detail(category, session.answers.tokens)
        if detail:
            session.answers.detail = detail
            session.answers.detail_label = options.detail_label(category, detail)
        return self._advance(session)

    def _text_detail(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        category = session.answers.category
        if category == "other" or not category:
            session.answers.tokens |= nlu.detect_tokens(raw)
            session.answers.detail = "other"
            session.answers.detail_label = "описание текстом"
            return self._advance(session)
        value = nlu.parse_detail(category, raw)
        if value is None:
            return self._reprompt(session)
        self._apply_pick(session, "detail", value)
        return self._advance(session)

    def _text_duration(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_duration(raw)
        if value is None:
            return self._reprompt(session)
        self._apply_pick(session, "duration", value)
        return self._advance(session)

    def _text_severity(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_severity(raw)
        if value is None:
            return self._reprompt(session)
        session.answers.severity = value
        return self._advance(session)

    def _text_flags(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        questions = self._questions_for(session, session.state)
        if session.rf_index >= len(questions):
            return self._render(session)
        value = nlu.parse_yes_no(raw)
        if value is None:
            return self._reprompt(session)
        question = questions[session.rf_index]
        if value == "yes":
            return self._flag(session, question.key)
        self._remember_unknown(session, question.key, value)
        session.rf_answers[question.key] = value
        session.rf_index += 1
        session.touch()
        return self._render(session)

    def _text_chronic(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        items = nlu.match_chronic(raw)
        if not items:
            return self._reprompt(session)
        session.answers.chronic = items
        return self._advance(session)

    def _text_meds(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_meds(raw)
        if value is None:
            return self._reprompt(session)
        session.answers.meds = value
        return self._advance(session)

    def _text_allergies(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_allergies(raw)
        if value is None:
            return self._reprompt(session)
        session.answers.allergies = value
        return self._advance(session)

    def _text_surgery(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.parse_yes_no(raw)
        if value is None:
            return self._reprompt(session)
        session.answers.surgery = None if value == "unknown" else value == "yes"
        return self._advance(session)

    def _text_heredity(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        items = nlu.match_heredity(raw)
        if not items:
            return self._reprompt(session)
        session.answers.heredity = items
        return self._advance(session)

    def _text_pregnancy(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_pregnancy(raw)
        if value is None:
            return self._reprompt(session)
        self._apply_pick(session, "pregnancy", value)
        return self._advance(session)

    def _text_habits(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_habits(raw)
        if value is None:
            return self._reprompt(session)
        self._apply_pick(session, "habits", value)
        return self._advance(session)

    def _text_payment(self, session: Session, raw: str) -> tuple[Outgoing, ...]:
        value = nlu.match_payment(raw)
        if value is None:
            return self._reprompt(session)
        self._apply_pick(session, "payment", value)
        return self._advance(session)


def _may_be_pregnant(answers: Answers) -> bool:
    if answers.sex is None:
        return True
    return _needs_pregnancy(answers)


def _needs_pregnancy(answers: Answers) -> bool:
    return answers.sex == "female" and answers.age is not None and 12 <= answers.age <= 55
