from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

_MODE_VALUES = {"polling", "webhook"}
_SECRET_RE = re.compile(r"^[A-Za-z0-9-]{32,256}$")
_DEFAULT_API_HOSTS = "platform-api2.max.ru"


def _load_env(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name = name.strip()
        if name.startswith("export "):
            name = name[len("export ") :].strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(name, value)


def _int(name: str, default: int, low: int, high: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise SystemExit(f"{name} должен быть целым числом") from exc
    return max(low, min(high, value))


def _float(name: str, default: float, low: float, high: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = float(raw.replace(",", "."))
    except ValueError as exc:
        raise SystemExit(f"{name} должен быть числом") from exc
    return max(low, min(high, value))


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on", "да"}


def _read_secret_file(name: str, base_dir: Path) -> str:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return ""
    path = Path(raw)
    if not path.is_absolute():
        path = base_dir / path
    if not path.is_file():
        raise SystemExit(f"Не найден файл секрета {name}: {path}")
    value = path.read_text(encoding="utf-8-sig").strip()
    if not value:
        raise SystemExit(f"Файл секрета {name} пуст: {path}")
    return value


def _https_url(raw: str, name: str, *, base_only: bool) -> str:
    try:
        parts = urlsplit(raw)
    except ValueError as exc:
        raise SystemExit(f"{name} содержит некорректный URL") from exc
    if parts.scheme != "https":
        raise SystemExit(f"{name} должен начинаться с https://")
    if not parts.hostname:
        raise SystemExit(f"{name} должен содержать имя хоста")
    if parts.username or parts.password:
        raise SystemExit(f"{name} не должен содержать логин или пароль")
    try:
        port = parts.port
    except ValueError as exc:
        raise SystemExit(f"{name} содержит некорректный порт") from exc
    if port not in {None, 443}:
        raise SystemExit(f"{name} должен использовать порт 443")
    if parts.query or parts.fragment:
        raise SystemExit(f"{name} не должен содержать query или fragment")
    if base_only and parts.path not in {"", "/"}:
        raise SystemExit(f"{name} не должен содержать путь")
    if not base_only and parts.path in {"", "/"}:
        raise SystemExit(f"{name} должен содержать путь webhook")
    return raw.rstrip("/") if base_only else raw


@dataclass(frozen=True, slots=True)
class Settings:
    token: str
    api_base: str
    mode: str
    poll_timeout: int
    poll_limit: int
    webhook_host: str
    webhook_port: int
    webhook_path: str
    webhook_url: str
    webhook_secret: str
    session_ttl: int
    history_limit: int
    messages_per_second: float
    log_level: str
    ca_bundle: str = ""
    insecure_ssl: bool = False
    db_path: str = "data/medbot.sqlite3"
    db_salt: str = ""
    admin_ids: frozenset[int] = frozenset()
    max_sessions: int = 10000
    session_max_age: int = 21600
    max_text_length: int = 4000
    max_inflight_updates: int = 50
    max_updates_per_request: int = 100
    webhook_max_body: int = 262144
    user_messages_per_minute: int = 60
    user_message_burst: int = 20


def load_settings(env_file: str | Path = ".env") -> Settings:
    env_path = Path(env_file)
    _load_env(env_path)
    base_dir = env_path.resolve().parent
    token = _read_secret_file("MAX_BOT_TOKEN_FILE", base_dir) or os.environ.get("MAX_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("Не задан MAX_BOT_TOKEN. Скопируйте .env.example в .env и вставьте токен бота.")
    mode = os.environ.get("BOT_MODE", "polling").strip().lower()
    if mode not in _MODE_VALUES:
        raise SystemExit("BOT_MODE должен быть polling или webhook")
    raw_api_base = os.environ.get("MAX_API_BASE", "https://platform-api2.max.ru").strip()
    api_base = _https_url(raw_api_base, "MAX_API_BASE", base_only=True)
    api_hosts = {
        item.strip().lower()
        for item in os.environ.get("MAX_API_HOSTS", _DEFAULT_API_HOSTS).split(",")
        if item.strip()
    }
    if not api_hosts:
        raise SystemExit("MAX_API_HOSTS не должен быть пустым")
    if urlsplit(api_base).hostname.lower() not in api_hosts:
        raise SystemExit(
            "MAX_API_BASE должен указывать на разрешённый хост из MAX_API_HOSTS: "
            + ", ".join(sorted(api_hosts))
        )
    path = os.environ.get("WEBHOOK_PATH", "/webhook").strip() or "/webhook"
    if not path.startswith("/"):
        path = "/" + path
    secret = _read_secret_file("WEBHOOK_SECRET_FILE", base_dir) or os.environ.get(
        "WEBHOOK_SECRET", ""
    ).strip()
    if secret and not _SECRET_RE.fullmatch(secret):
        raise SystemExit("WEBHOOK_SECRET: разрешены латинские буквы, цифры и дефис, длина 32–256")
    webhook_url = os.environ.get("WEBHOOK_URL", "").strip()
    if mode == "webhook":
        if not secret:
            raise SystemExit("Для BOT_MODE=webhook задайте WEBHOOK_SECRET: иначе endpoint открыт всем")
        if not webhook_url:
            raise SystemExit("Для BOT_MODE=webhook задайте WEBHOOK_URL")
        webhook_url = _https_url(webhook_url, "WEBHOOK_URL", base_only=False)
        if urlsplit(webhook_url).path != path:
            raise SystemExit("Путь WEBHOOK_URL должен совпадать с WEBHOOK_PATH")
    elif webhook_url:
        webhook_url = _https_url(webhook_url, "WEBHOOK_URL", base_only=False)
    ca_bundle = os.environ.get("MAX_CA_BUNDLE", "").strip()
    if ca_bundle and not Path(ca_bundle).is_absolute():
        ca_bundle = str(base_dir / ca_bundle)
    if not ca_bundle:
        for name in ("russian_trusted_bundle.pem", "russian_trusted_root_ca.pem"):
            candidate = base_dir / "certs" / name
            if candidate.is_file():
                ca_bundle = str(candidate)
                break
    insecure_ssl = _bool("MAX_INSECURE_SSL", False)
    if mode == "webhook" and insecure_ssl:
        raise SystemExit("MAX_INSECURE_SSL=1 недопустим в режиме webhook")
    db_path = os.environ.get("DB_PATH", "data/medbot.sqlite3").strip() or "data/medbot.sqlite3"
    if not Path(db_path).is_absolute():
        db_path = str(base_dir / db_path)
    admin_ids: set[int] = set()
    for chunk in os.environ.get("ADMIN_IDS", "").replace(";", ",").split(","):
        chunk = chunk.strip()
        if chunk.lstrip("-").isdigit():
            admin_ids.add(int(chunk))
    return Settings(
        token=token,
        api_base=api_base,
        mode=mode,
        poll_timeout=_int("POLL_TIMEOUT", 30, 1, 90),
        poll_limit=_int("POLL_LIMIT", 100, 1, 1000),
        webhook_host=os.environ.get("WEBHOOK_HOST", "127.0.0.1").strip() or "127.0.0.1",
        webhook_port=_int("WEBHOOK_PORT", 8080, 1, 65535),
        webhook_path=path,
        webhook_url=webhook_url,
        webhook_secret=secret,
        session_ttl=_int("SESSION_TTL", 7200, 300, 86400),
        history_limit=_int("HISTORY_LIMIT", 5, 1, 20),
        messages_per_second=_float("MESSAGES_PER_SECOND", 1.8, 0.5, 1.9),
        log_level=os.environ.get("LOG_LEVEL", "INFO").strip().upper() or "INFO",
        ca_bundle=ca_bundle,
        insecure_ssl=insecure_ssl,
        db_path=db_path,
        db_salt=os.environ.get("DB_SALT", "").strip(),
        admin_ids=frozenset(admin_ids),
        max_sessions=_int("MAX_SESSIONS", 10000, 100, 1000000),
        session_max_age=_int("SESSION_MAX_AGE", 21600, 300, 604800),
        max_text_length=_int("MAX_TEXT_LENGTH", 4000, 100, 20000),
        max_inflight_updates=_int("MAX_INFLIGHT_UPDATES", 50, 1, 1000),
        max_updates_per_request=_int("MAX_UPDATES_PER_REQUEST", 100, 1, 1000),
        webhook_max_body=_int("WEBHOOK_MAX_BODY", 262144, 1024, 10485760),
        user_messages_per_minute=_int("USER_MESSAGES_PER_MINUTE", 60, 1, 10000),
        user_message_burst=_int("USER_MESSAGE_BURST", 20, 1, 10000),
    )
