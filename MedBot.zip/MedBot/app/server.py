from __future__ import annotations

import asyncio
import contextlib
import hmac
import logging

from aiohttp import web

from .config import Settings
from .dispatcher import Dispatcher
from .max_api import MaxApiError, MaxClient

log = logging.getLogger(__name__)

UPDATE_TYPES: tuple[str, ...] = (
    "message_created",
    "message_callback",
    "bot_started",
    "bot_stopped",
    "dialog_cleared",
    "dialog_removed",
)


def _consume_task(task: asyncio.Task[None]) -> None:
    with contextlib.suppress(asyncio.CancelledError, Exception):
        task.exception()


async def run_polling(client: MaxClient, dispatcher: Dispatcher, settings: Settings) -> None:
    marker: int | None = None
    pending: set[asyncio.Task[None]] = set()
    gate = asyncio.Semaphore(settings.max_inflight_updates)

    def done(task: asyncio.Task[None]) -> None:
        pending.discard(task)
        _consume_task(task)

    async def process(update: dict) -> None:
        async with gate:
            await dispatcher.handle_update(update)

    async def submit(update: dict) -> None:
        if len(pending) >= settings.max_inflight_updates:
            await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
        task = asyncio.create_task(process(update))
        pending.add(task)
        task.add_done_callback(done)

    log.info("long polling запущен, таймаут %s с", settings.poll_timeout)
    try:
        while True:
            try:
                page = await client.get_updates(
                    marker=marker,
                    timeout=settings.poll_timeout,
                    limit=settings.poll_limit,
                )
            except MaxApiError as exc:
                if exc.status == 401:
                    raise
                log.warning("long polling: %s", exc)
                await asyncio.sleep(3)
                continue
            updates = page.get("updates") or []
            page_marker = page.get("marker")
            if isinstance(page_marker, int):
                marker = page_marker
            elif isinstance(page_marker, str) and page_marker.lstrip("-").isdigit():
                marker = int(page_marker)
            for update in updates:
                if not isinstance(update, dict):
                    continue
                await submit(update)
            if not updates:
                await asyncio.sleep(0.2)
    finally:
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)


def build_webhook_app(dispatcher: Dispatcher, settings: Settings) -> web.Application:
    if not settings.webhook_secret or len(settings.webhook_secret) < 32:
        raise RuntimeError("WEBHOOK_SECRET не задан или короче 32 символов")
    pending: set[asyncio.Task[None]] = set()
    gate = asyncio.Semaphore(settings.max_inflight_updates)

    def done(task: asyncio.Task[None]) -> None:
        pending.discard(task)
        _consume_task(task)

    async def process(update: dict) -> None:
        async with gate:
            await dispatcher.handle_update(update)

    def submit(update: dict) -> bool:
        if len(pending) >= settings.max_inflight_updates:
            return False
        task = asyncio.create_task(process(update))
        pending.add(task)
        task.add_done_callback(done)
        return True

    async def handle(request: web.Request) -> web.Response:
        secret = request.headers.get("X-Max-Bot-Api-Secret", "")
        if not hmac.compare_digest(secret, settings.webhook_secret):
            raise web.HTTPForbidden(text="forbidden")
        if request.content_type != "application/json":
            raise web.HTTPUnsupportedMediaType(text="application/json required")
        try:
            payload = await request.json()
        except ValueError as exc:
            raise web.HTTPBadRequest(text="invalid json") from exc
        if not isinstance(payload, dict):
            raise web.HTTPBadRequest(text="object expected")
        raw_updates = payload.get("updates")
        updates = raw_updates if isinstance(raw_updates, list) else [payload]
        if len(updates) > settings.max_updates_per_request:
            raise web.HTTPRequestEntityTooLarge(
                max_size=settings.max_updates_per_request,
                actual_size=len(updates),
            )
        for update in updates:
            if not isinstance(update, dict) or update.get("update_type") not in UPDATE_TYPES:
                continue
            if not submit(update):
                return web.json_response(
                    {"ok": False, "error": "busy"},
                    status=503,
                    headers={"Retry-After": "1"},
                )
        return web.json_response({"ok": True})

    async def health(_: web.Request) -> web.Response:
        return web.json_response({"ok": True}, headers={"Cache-Control": "no-store"})

    async def shutdown(_: web.Application) -> None:
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

    app = web.Application(client_max_size=settings.webhook_max_body)
    app.router.add_post(settings.webhook_path, handle)
    app.router.add_get("/health", health)
    app.on_shutdown.append(shutdown)
    return app


async def run_webhook(client: MaxClient, dispatcher: Dispatcher, settings: Settings) -> None:
    if not settings.webhook_secret or len(settings.webhook_secret) < 32:
        raise SystemExit("Для BOT_MODE=webhook задайте WEBHOOK_SECRET длиной 32+ символа")
    if not settings.webhook_url:
        raise SystemExit("Для BOT_MODE=webhook задайте WEBHOOK_URL")
    app = build_webhook_app(dispatcher, settings)
    try:
        await client.subscribe(settings.webhook_url, list(UPDATE_TYPES), settings.webhook_secret)
        log.info("подписка на webhook оформлена: %s", settings.webhook_url)
    except MaxApiError as exc:
        log.error("не удалось оформить подписку на webhook: %s", exc)
        raise SystemExit(2) from exc
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, settings.webhook_host, settings.webhook_port)
    await site.start()
    log.info("webhook слушает http://%s:%s%s", settings.webhook_host, settings.webhook_port, settings.webhook_path)
    try:
        await asyncio.Event().wait()
    finally:
        await runner.cleanup()
