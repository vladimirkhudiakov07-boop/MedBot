from __future__ import annotations

import asyncio
import json
import logging
import ssl
import time
from pathlib import Path
from typing import Any

import aiohttp

from .config import Settings

log = logging.getLogger(__name__)

RETRYABLE = {429, 500, 502, 503, 504}


class MaxApiError(RuntimeError):
    def __init__(self, status: int, code: str = "", message: str = "") -> None:
        self.status = status
        self.code = code
        self.message = message
        super().__init__(f"MAX API {status}: {code or 'error'} {message}".strip())


class RateLimiter:
    def __init__(self, per_second: float) -> None:
        self._interval = 1.0 / max(per_second, 0.1)
        self._last: dict[str, float] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    async def wait(self, key: str) -> None:
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            now = time.monotonic()
            delay = self._last.get(key, 0.0) + self._interval - now
            if delay > 0:
                await asyncio.sleep(delay)
                now = time.monotonic()
            self._last[key] = now
            self._prune(now)

    def _prune(self, now: float) -> None:
        if len(self._last) <= 512:
            return
        stale = [key for key, stamp in self._last.items() if now - stamp > 600]
        for key in stale:
            self._last.pop(key, None)
            self._locks.pop(key, None)


class MaxClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._session: aiohttp.ClientSession | None = None
        self._limiter = RateLimiter(settings.messages_per_second)

    async def __aenter__(self) -> MaxClient:
        await self.open()
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.close()

    async def open(self) -> None:
        if self._session is not None and not self._session.closed:
            return
        connector = aiohttp.TCPConnector(ssl=_ssl_context(self._settings))
        self._session = aiohttp.ClientSession(
            connector=connector,
            headers={"Authorization": self._settings.token},
            timeout=aiohttp.ClientTimeout(total=30, connect=10),
        )

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
        self._session = None

    @property
    def http(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            raise RuntimeError("HTTP-сессия клиента не открыта")
        return self._session

    async def _call(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
        timeout: float | None = None,
        retries: int = 3,
        retry_statuses: set[int] | None = None,
        retry_network: bool = True,
    ) -> dict[str, Any]:
        url = f"{self._settings.api_base}{path}"
        allowed = retry_statuses if retry_statuses is not None else RETRYABLE
        clean_params = {key: value for key, value in (params or {}).items() if value is not None}
        request_kwargs: dict[str, Any] = {}
        if clean_params:
            request_kwargs["params"] = clean_params
        if payload is not None:
            request_kwargs["json"] = payload
        if timeout is not None:
            request_kwargs["timeout"] = aiohttp.ClientTimeout(total=timeout)

        last_error: Exception | None = None
        for attempt in range(max(1, retries)):
            try:
                async with self.http.request(
                    method, url, allow_redirects=False, **request_kwargs
                ) as response:
                    body = await response.text()
                    data = _parse(body)
                    if response.status == 200:
                        if isinstance(data, dict) and data.get("success") is False:
                            raise MaxApiError(200, str(data.get("code", "")), str(data.get("message", "")))
                        return data if isinstance(data, dict) else {"result": data}
                    error = MaxApiError(response.status, _field(data, "code"), _field(data, "message"))
                    if response.status in allowed and attempt + 1 < retries:
                        await asyncio.sleep(_retry_delay(attempt, response))
                        continue
                    raise error
            except MaxApiError:
                raise
            except (aiohttp.ClientError, TimeoutError) as exc:
                last_error = exc
                if not retry_network or attempt + 1 >= retries:
                    break
                await asyncio.sleep(min(2**attempt, 8))
        raise MaxApiError(0, "network", str(last_error or "нет соединения"))

    async def get_me(self) -> dict[str, Any]:
        return await self._call("GET", "/me", retries=2)

    async def get_updates(
        self,
        marker: int | None,
        timeout: int,
        limit: int,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"timeout": timeout, "limit": limit}
        if marker is not None:
            params["marker"] = marker
        return await self._call("GET", "/updates", params=params, timeout=timeout + 20, retries=1)

    async def send_message(
        self,
        target: dict[str, int],
        text: str,
        keyboard: dict[str, Any] | None = None,
        notify: bool = True,
        rate_key: str | None = None,
    ) -> dict[str, Any]:
        await self._limiter.wait(rate_key or str(target))
        payload: dict[str, Any] = {"text": _fit_text(text), "notify": notify, "format": "markdown"}
        if keyboard:
            payload["attachments"] = [keyboard]
        return await self._call(
            "POST",
            "/messages",
            params=target,
            payload=payload,
            retries=3,
            retry_statuses={429},
            retry_network=False,
        )

    async def edit_message(
        self,
        message_id: str,
        text: str,
        keyboard: dict[str, Any] | None = None,
        rate_key: str | None = None,
    ) -> dict[str, Any]:
        await self._limiter.wait(rate_key or f"m{message_id}")
        payload: dict[str, Any] = {"text": _fit_text(text), "notify": False, "format": "markdown"}
        if keyboard:
            payload["attachments"] = [keyboard]
        return await self._call("PUT", "/messages", params={"message_id": message_id}, payload=payload)

    async def answer_callback(
        self,
        callback_id: str,
        text: str,
        keyboard: dict[str, Any] | None = None,
        rate_key: str | None = None,
    ) -> dict[str, Any]:
        await self._limiter.wait(rate_key or f"cb{callback_id}")
        message: dict[str, Any] = {"text": _fit_text(text), "notify": False, "format": "markdown"}
        if keyboard:
            message["attachments"] = [keyboard]
        return await self._call(
            "POST",
            "/answers",
            params={"callback_id": callback_id},
            payload={"message": message},
        )

    async def set_commands(self, commands: tuple[dict[str, str], ...]) -> dict[str, Any]:
        return await self._call("PATCH", "/me/commands", payload={"commands": list(commands)}, retries=2)

    async def subscribe(self, url: str, update_types: list[str], secret: str) -> dict[str, Any]:
        payload: dict[str, Any] = {"url": url, "update_types": update_types}
        if secret:
            payload["secret"] = secret
        return await self._call("POST", "/subscriptions", payload=payload, retries=2)

    async def get_subscriptions(self) -> list[dict[str, Any]]:
        data = await self._call("GET", "/subscriptions", retries=2)
        subscriptions = data.get("subscriptions")
        return subscriptions if isinstance(subscriptions, list) else []

    async def delete_subscription(self, url: str) -> dict[str, Any]:
        return await self._call("DELETE", "/subscriptions", params={"url": url}, retries=2)


def _ssl_context(settings: Settings) -> ssl.SSLContext | bool:
    if settings.insecure_ssl:
        log.warning("MAX_INSECURE_SSL=1: проверка TLS-сертификата отключена, это только для отладки")
        return False
    context = ssl.create_default_context()
    if settings.ca_bundle:
        path = Path(settings.ca_bundle)
        if not path.is_file():
            raise SystemExit(f"Не найден файл сертификата MAX_CA_BUNDLE: {path}")
        context.load_verify_locations(cafile=str(path))
    return context


def _fit_text(text: str, limit: int = 4000) -> str:
    if len(text) <= limit:
        return text
    cut = text[: limit - 8]
    space = cut.rfind(" ")
    if space > limit // 2:
        cut = cut[:space]
    if cut.count("**") % 2:
        cut += "**"
    return cut


def _parse(body: str) -> Any:
    if not body:
        return {}
    try:
        return json.loads(body)
    except ValueError:
        return {"raw": body}


def _field(data: Any, name: str) -> str:
    if isinstance(data, dict):
        value = data.get(name)
        if isinstance(value, str):
            return value
    return ""


def _retry_delay(attempt: int, response: aiohttp.ClientResponse) -> float:
    header = response.headers.get("Retry-After", "")
    try:
        return max(0.5, min(float(header), 30.0))
    except ValueError:
        return min(2**attempt, 8)
