from __future__ import annotations

import hashlib
import logging
import time
from typing import Any

from . import texts, triage
from .database import Database
from .dialog import CallbackOutcome, Dialog
from .keyboards import decode_payload
from .limits import Deduplicator, TokenBucket
from .max_api import MaxApiError, MaxClient
from .models import Outgoing, ReplyTarget
from .sessions import Session, SessionStore

log = logging.getLogger(__name__)

MAX_CALLBACK_PAYLOAD = 4096
WELCOME_DEDUPE_SECONDS = 5.0


class Dispatcher:
    def __init__(
        self,
        client: MaxClient,
        store: SessionStore,
        dialog: Dialog,
        *,
        database: Database | None = None,
        admin_ids: frozenset[int] = frozenset(),
        max_text_length: int = 4000,
        user_messages_per_minute: int = 60,
        user_message_burst: int = 20,
        dedupe_ttl: int = 3600,
        dedupe_max: int = 10000,
    ) -> None:
        self._client = client
        self._store = store
        self._dialog = dialog
        self._database = database
        self._admin_ids = admin_ids
        self._max_text_length = max(100, max_text_length)
        self._dedupe = Deduplicator(max_entries=dedupe_max, ttl_seconds=dedupe_ttl)
        self._inbound = TokenBucket(
            per_minute=max(1, user_messages_per_minute),
            burst=max(1, user_message_burst),
        )

    async def handle_update(self, update: dict[str, Any]) -> None:
        kind = update.get("update_type")
        update_id = update.get("update_id")
        if update_id is not None and not self._remember(f"upd:{update_id}"):
            return
        try:
            if kind == "message_created":
                await self._on_message(update)
            elif kind == "message_callback":
                await self._on_callback(update)
            elif kind == "bot_started":
                await self._on_bot_started(update)
            elif kind in {"dialog_cleared", "dialog_removed", "bot_stopped"}:
                self._on_reset(update)
        except MaxApiError as exc:
            log.warning("ошибка MAX API при обработке %s: %s", kind, exc)
        except Exception:
            log.exception("не удалось обработать событие %s", kind)

    async def _on_message(self, update: dict[str, Any]) -> None:
        message = update.get("message") or {}
        sender = message.get("sender") or {}
        if sender.get("is_bot"):
            return
        body = message.get("body") or {}
        mid = str(body.get("mid") or "")
        if mid and not self._remember(f"mid:{mid}"):
            return
        recipient = message.get("recipient") or {}
        target = ReplyTarget.from_message(message)
        if not target.key:
            return
        if not self._inbound.allow(target.key):
            log.debug("входящий лимит для %s", _tag(target.key))
            return
        if recipient.get("chat_type") != "dialog":
            await self._send(target, texts.group_hint())
            return
        session = self._store.get_or_create(target.key, target.chat_id, target.user_id)
        async with session.lock:
            if _has_audio(body):
                await self._send(target, texts.audio_hint())
                return
            text = str(body.get("text") or "").strip()
            if len(text) > self._max_text_length:
                await self._send(target, texts.text_too_long(self._max_text_length))
                return
            if text.startswith("/"):
                await self._command(session, target, text)
                return
            if text.lower() in {"история", "моя история"}:
                await self._deliver(target, await self._history_messages(session))
                return
            if not text:
                await self._send(target, texts.attachment_hint())
                return
            await self._deliver(target, self._dialog.handle_text(session, text))
            await self._track(session)

    async def _on_callback(self, update: dict[str, Any]) -> None:
        callback = update.get("callback") or {}
        callback_id = str(callback.get("callback_id") or "")
        if callback_id and not self._remember(f"cb:{callback_id}"):
            return
        target = _callback_target(update)
        if target is None or not target.key:
            if callback_id:
                try:
                    await self._client.answer_callback(callback_id, texts.stale_button_text())
                except MaxApiError as exc:
                    log.debug("не удалось ответить на устаревшую кнопку: %s", exc)
            return
        if not self._inbound.allow(target.key):
            log.debug("входящий лимит для %s", _tag(target.key))
            return
        raw_payload = str(callback.get("payload") or "")
        if len(raw_payload) > MAX_CALLBACK_PAYLOAD:
            if callback_id:
                try:
                    await self._client.answer_callback(callback_id, texts.stale_button_text())
                except MaxApiError as exc:
                    log.debug("не удалось ответить на слишком большой payload: %s", exc)
            return
        payload = decode_payload(raw_payload)
        if not target.dialog:
            if callback_id:
                try:
                    await self._client.answer_callback(
                        callback_id, texts.group_hint(), rate_key=target.key
                    )
                except MaxApiError as exc:
                    log.debug("не удалось ответить в групповом чате: %s", exc)
            return
        session = self._store.get_or_create(target.key, target.chat_id, target.user_id)
        async with session.lock:
            if payload.get("k") == "nav" and payload.get("v") == "history":
                if callback_id:
                    try:
                        await self._client.answer_callback(
                            callback_id, "📜 История", rate_key=target.key
                        )
                    except MaxApiError as exc:
                        log.debug("не удалось ответить на кнопку истории: %s", exc)
                await self._deliver(target, await self._history_messages(session))
                return
            if payload.get("k") == "nav" and payload.get("v") == "stats":
                if callback_id:
                    try:
                        await self._client.answer_callback(
                            callback_id, "📊 Статистика", rate_key=target.key
                        )
                    except MaxApiError as exc:
                        log.debug("не удалось ответить на кнопку статистики: %s", exc)
                await self._deliver(target, await self._stats_messages(target))
                return
            outcome: CallbackOutcome = self._dialog.handle_callback(session, payload)
            ack_text = outcome.ack_text if outcome.ack_text is not None else texts.stale_button_text()
            if callback_id:
                try:
                    await self._client.answer_callback(
                        callback_id, ack_text, outcome.ack_keyboard, rate_key=target.key
                    )
                except MaxApiError as exc:
                    log.debug("не удалось обновить исходное сообщение: %s", exc)
            await self._deliver(target, outcome.messages)
            await self._track(session)

    async def _on_bot_started(self, update: dict[str, Any]) -> None:
        user = update.get("user") or {}
        if user.get("is_bot"):
            return
        target = ReplyTarget.from_update(update)
        if not target.key:
            return
        if not self._inbound.allow(target.key):
            log.debug("входящий лимит для %s", _tag(target.key))
            return
        session = self._store.get_or_create(target.key, target.chat_id, target.user_id)
        async with session.lock:
            if session.state == "start" and time.time() - session.welcome_at < WELCOME_DEDUPE_SECONDS:
                return
            await self._deliver(target, self._dialog.welcome(session))

    def _on_reset(self, update: dict[str, Any]) -> None:
        target = ReplyTarget.from_update(update)
        if target.key:
            self._store.drop(target.key)

    async def _command(self, session: Session, target: ReplyTarget, text: str) -> None:
        command = text.split()[0].split("@")[0].lower()
        if command in {"/start", "/restart"}:
            if (
                command == "/start"
                and session.state == "start"
                and time.time() - session.welcome_at < WELCOME_DEDUPE_SECONDS
            ):
                return
            messages = self._dialog.welcome(session)
        elif command == "/help":
            messages = self._dialog.help()
        elif command == "/history":
            messages = await self._history_messages(session)
        elif command == "/stats":
            messages = await self._stats_messages(target)
        elif command == "/forget":
            messages = await self._forget_messages(session)
        elif command == "/stop":
            self._dialog.reset(session)
            self._store.drop(session.key)
            messages = (Outgoing(texts.farewell_text(), texts.start_keyboard()),)
        else:
            messages = self._dialog.help()
        await self._deliver(target, messages)

    async def _track(self, session: Session) -> None:
        if self._database is None:
            return
        try:
            if session.state != "start" and not session.survey_started:
                session.survey_started = True
                session.started_at = time.time()
                await self._database.log_event(session.key, "survey_started")
            if session.completed and not session.persisted:
                result = session.result or triage.evaluate(session.answers)
                await self._database.save_request(
                    session.key, session.answers, result, session.started_at
                )
                session.persisted = True
        except Exception:
            log.exception("не удалось сохранить статистику обращения")

    async def _history_messages(self, session: Session) -> tuple[Outgoing, ...]:
        if self._database is None:
            return (Outgoing("История пока недоступна: база не подключена.", texts.resume_keyboard()),)
        items = await self._database.history(session.key)
        return (Outgoing(texts.history_text(items), texts.resume_keyboard()),)

    async def _stats_messages(self, target: ReplyTarget) -> tuple[Outgoing, ...]:
        if self._database is None or target.user_id not in self._admin_ids:
            return (Outgoing(texts.stats_denied_text(target.user_id), texts.resume_keyboard()),)
        stats = await self._database.stats()
        return (Outgoing(texts.stats_text(stats), texts.resume_keyboard()),)

    async def _forget_messages(self, session: Session) -> tuple[Outgoing, ...]:
        if self._database is None:
            return (Outgoing("История пока недоступна: база не подключена.", texts.resume_keyboard()),)
        removed = await self._database.delete_history(session.key)
        return (Outgoing(texts.forget_text(removed), texts.resume_keyboard()),)

    async def _deliver(self, target: ReplyTarget, messages: tuple[Outgoing, ...]) -> None:
        for message in messages:
            try:
                await self._client.send_message(
                    target.params(), message.text, message.keyboard, rate_key=target.key
                )
            except MaxApiError as exc:
                log.warning("не удалось отправить сообщение %s: %s", _tag(target.key), exc)

    async def _send(self, target: ReplyTarget, text: str) -> None:
        try:
            await self._client.send_message(target.params(), text, rate_key=target.key)
        except MaxApiError as exc:
            log.warning("не удалось отправить сообщение %s: %s", _tag(target.key), exc)

    def _remember(self, token: str) -> bool:
        return self._dedupe.remember(token)


def _callback_target(update: dict[str, Any]) -> ReplyTarget | None:
    message = update.get("message") or {}
    recipient = message.get("recipient") or {}
    chat_type = recipient.get("chat_type")
    chat_id = recipient.get("chat_id") or update.get("chat_id")
    callback = update.get("callback") or {}
    callback_user_id = (callback.get("user") or {}).get("user_id")
    recipient_user_id = recipient.get("user_id")
    if chat_type == "dialog":
        if (
            callback_user_id is not None
            and recipient_user_id is not None
            and callback_user_id != recipient_user_id
        ):
            return None
        user_id = callback_user_id or recipient_user_id
        return ReplyTarget(chat_id=chat_id, user_id=user_id, dialog=True, key=f"u{user_id or chat_id}")
    if chat_type in {"chat", "channel"}:
        return ReplyTarget(chat_id=chat_id, dialog=False, key=f"c{chat_id}")
    return None


def _has_audio(body: dict[str, Any]) -> bool:
    for attachment in body.get("attachments") or ():
        if isinstance(attachment, dict) and attachment.get("type") == "audio":
            return True
    return False


def _tag(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:8]
