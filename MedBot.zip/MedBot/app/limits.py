from __future__ import annotations

import time
from collections import OrderedDict


class Deduplicator:
    def __init__(self, max_entries: int = 10000, ttl_seconds: int = 3600) -> None:
        self._max_entries = max(1, max_entries)
        self._ttl = max(1, ttl_seconds)
        self._seen: OrderedDict[str, float] = OrderedDict()

    def remember(self, token: str) -> bool:
        if not token:
            return True
        now = time.monotonic()
        expiry = self._seen.get(token)
        if expiry is not None and expiry > now:
            self._seen.move_to_end(token)
            return False
        self._seen[token] = now + self._ttl
        self._seen.move_to_end(token)
        self._prune(now)
        return True

    def _prune(self, now: float) -> None:
        while self._seen:
            token, expiry = next(iter(self._seen.items()))
            if expiry > now and len(self._seen) <= self._max_entries:
                break
            self._seen.pop(token, None)


class TokenBucket:
    def __init__(self, per_minute: int, burst: int) -> None:
        self._rate = max(per_minute, 1) / 60.0
        self._capacity = float(max(burst, 1))
        self._buckets: OrderedDict[str, tuple[float, float]] = OrderedDict()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        tokens, updated = self._buckets.get(key, (self._capacity, now))
        tokens = min(self._capacity, tokens + (now - updated) * self._rate)
        allowed = tokens >= 1.0
        if allowed:
            tokens -= 1.0
        self._buckets[key] = (tokens, now)
        self._buckets.move_to_end(key)
        while len(self._buckets) > 10000:
            self._buckets.popitem(last=False)
        return allowed
