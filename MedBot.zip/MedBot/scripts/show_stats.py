from __future__ import annotations

import asyncio
import contextlib
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config import load_settings
from app.database import Database
from app.texts import stats_text


async def main() -> None:
    os.chdir(Path(__file__).resolve().parents[1])
    settings = load_settings()
    database = Database(settings.db_path, settings.db_salt)
    await database.connect()
    try:
        text = stats_text(await database.stats()).replace("**", "")
        with contextlib.suppress(AttributeError, ValueError):
            sys.stdout.reconfigure(encoding="utf-8")
        print(text)
    finally:
        await database.close()


if __name__ == "__main__":
    asyncio.run(main())
