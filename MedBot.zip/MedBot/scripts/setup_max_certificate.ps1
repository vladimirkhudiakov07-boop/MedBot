param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$certsDir = Join-Path $projectRoot "certs"
New-Item -ItemType Directory -Path $certsDir -Force | Out-Null

$sources = [ordered]@{
    "russian_trusted_root_ca.pem" = "https://gu-st.ru/content/lending/russian_trusted_root_ca_pem.crt"
    "russian_trusted_sub_ca.pem"  = "https://gu-st.ru/content/lending/russian_trusted_sub_ca_pem.crt"
}

foreach ($name in $sources.Keys) {
    $target = Join-Path $certsDir $name
    if ((Test-Path -LiteralPath $target) -and -not $Force) {
        Write-Host "Уже скачан: $target"
        continue
    }
    Write-Host "Скачиваю $($sources[$name])"
    try {
        Invoke-WebRequest -Uri $sources[$name] -OutFile $target
    }
    catch {
        throw "Не удалось скачать $($sources[$name]). Откройте ссылку в браузере, сохраните файл как $target и запустите скрипт снова."
    }
    if (-not (Select-String -LiteralPath $target -Pattern "BEGIN CERTIFICATE" -Quiet)) {
        throw "Файл $target не похож на PEM-сертификат. Скачайте сертификаты вручную с gu-st.ru."
    }
}

$bundle = Join-Path $certsDir "russian_trusted_bundle.pem"
Get-Content -LiteralPath (Join-Path $certsDir "russian_trusted_root_ca.pem"), (Join-Path $certsDir "russian_trusted_sub_ca.pem") |
    Set-Content -LiteralPath $bundle -Encoding ascii

Write-Host ""
Write-Host "Готово: $bundle"
Write-Host "Бот подхватит этот файл автоматически. Перезапустите: python main.py"
